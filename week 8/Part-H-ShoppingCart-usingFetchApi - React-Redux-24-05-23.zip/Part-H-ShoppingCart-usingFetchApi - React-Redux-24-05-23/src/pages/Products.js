import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
// import Skeleton from "react-loading-skeleton";

const Products = () => {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState(data);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const getProducts = async () => {
      setLoading(true);
      let response = await fetch("https://fakestoreapi.com/products");      
      response = await response.json();
        setData(response);
        setFilter(response);
        setLoading(false);
        console.log(filter);
      }

      

    getProducts();
  }, []);



  const Loading = () => {
    return (
    <>
       <h1>Loading.....</h1>
    </>
    );
  };

  const filterProduct = (cat) => {
      const updatedList = data.filter((x)=>x.category === cat);
      setFilter(updatedList);
  }

  const ShowProducts = () => {
    return (
      <>
        <div className="buttons d-flex justify-content-center mb-5 pb-5">
          <button className="btn btn-outline-dark me-2" onClick={()=>setFilter(data)}>All</button>
          <button className="btn btn-outline-dark me-2" onClick={()=>filterProduct("men's clothing")}>Men's Clothing</button>
          <button className="btn btn-outline-dark me-2" onClick={()=>filterProduct("women's clothing")}>
            Women's Clothing
          </button>
          <button className="btn btn-outline-dark me-2" onClick={()=>filterProduct("jewelery")}>Jewelery</button>
          <button className="btn btn-outline-dark me-2" onClick={()=>filterProduct("electronics")}>Electronic</button>
        </div>
        {filter.map((product) => {
          return (
            <>
              <div className="col-md-3 mb-4">
                <div class="card h-100 text-center p-4" key={product.id}>
                  <img src={product.image} class="card-img-top" alt={product.title} height="250px" />
                  <div class="card-body">
                    <h5 class="card-title mb-0">{product.title.substring(0,12)}...</h5>
                    <p class="card-text lead fw-bold">
                      Rs.{product.price}
                    </p>
                    <Link to={`/products/${product.id}`} class="btn btn-outline-dark">
                      Buy Now
                    </Link>
                  </div>
                </div>
              </div>
            </>
          );
        })}
      </>
    );
  };
  return (
    <div>
      <div className="container my-5 py-5">
        <div className="row">
          <div className="col-12 mb-5">
            <h1 className="display-6 fw-bolder text-center">Latest Products</h1>
            <hr />
          </div>
        </div>
        <div className="row justify-content-center">
          {loading ? <Loading /> : <ShowProducts />}
        </div>
      </div>
    </div>
  );
};

export default Products;





// import React, { useEffect, useState } from "react";
// import { Link } from "react-router-dom";

// const Products = () => {
//   const [prod, setProd] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const[filteredProduct, setFilteredProduct] = useState([])
 
//   // getting products from fake api store
//   const getProducts = async () => {
//     setLoading(true);
//     let res = await fetch("https://fakestoreapi.com/products");
//     res = await res.json();
//     setProd(res);    
//     setFilteredProduct(res);    
//     setLoading(false);
//     console.log(prod);
//   };

//   // Loading products on page load automatically
//   useEffect(() => {
//     getProducts();
//   }, []);

//   // Loading component
//   const LoadingComp = () => {
//     return (
//       <>
//         <div
//           style={{ width: "12rem", height: "12rem" }}
//           className=" spinner-border text-danger"
//           role="status"
//         >
//           <span className="visually-hidden">Loading...</span>
//         </div>
//       </>
//     );
//   };

//   // Filtered Data on the Basis of Category: 
//   // User will click on button, the relevant data will be filtered
//   const filterData = (cat) =>{
//     const updateData = prod.filter(x => x.category === cat)
//     setFilteredProduct(updateData)
//   }



//   const ShowProducts = () => {
//     return (
//       <>
//         <>
//         {/* Creating button for All, men, women, jewelry, electronics */}
//           <div className="buttons mb-5 d-flex justify-content-center" role="group" aria-label="Basic example">
            
//             <button onClick={()=>setFilteredProduct(prod)}
//             type="button" className="btn btn-outline-dark">
//               all
//             </button>
//             <button onClick={()=>filterData("men's clothing")}
//             type="button" className="btn btn-outline-dark">
//               men's clothing
//             </button>
//             <button onClick={()=>filterData("women's clothing")}
//             type="button" className="btn btn-outline-dark">
//               women's clothing
//             </button>
//             <button onClick={()=>filterData("jewelery")}
//             type="button" className="btn btn-outline-dark">
//               jewelery
//             </button>
//             <button onClick={()=>filterData("electronics")}
//             type="button" className="btn btn-outline-dark">
//               electronics
//             </button>
//           </div>
//         </>

//         {/* mapping the data obtained through api */}
//         {filteredProduct.map((product) => {
//           return (
//             <div className="col-md-3 mb-5">
//               <div className="card h-100" style={{ width: "16rem" }}>
//                 <img
//                   src={product.image}
//                   className="card-img-top"
//                   height={350}
//                   alt="photo"
//                 />
//                 <div className="card-body">
//                   <h5 className="card-title">
//                     {product.title.substring(0, 15)}...
//                   </h5>
//                   <p className="card-text">
//                     {product.description.substring(0, 50)}...
//                   </p>
//                   <Link to={`/products/${product.id}`} className="btn btn-outline-dark">
//                     Buy Now
//                   </Link>
//                 </div>
//               </div>
//             </div>
//           );
//         })}
//       </>
//     );
//   };

//   return (
//     <div className="container py-5">
//       <div className="row py-4">
//         {loading ? <LoadingComp /> : <ShowProducts />}
//       </div>
//     </div>
//   );
// };

// export default Products;
