

// https://jsonplaceholder.typicode.com/users
// actions 

import { useEffect } from "react"
import { useDispatch } from "react-redux"
import axios from "axios";

const dispatch = useDispatch();


const userAction = () => dispatch = async() => {
    try {
        dispatch({type: "GET_USER_REQUEST"})
        let {data} = await axios.get("https://jsonplaceholder.typicode.com/users")
        dispatch({type: "GET_USER_SUCCESS", payload: data})        
        console.log(res.data)
    } catch (error) {
        dispatch({type: "GET_USER_ERROR", 
        payload:error.data && error.response.data.message ? 
        error.response.data.message : error.message

    })
        
    }
}

useEffect(()=>{
    dispatch(userAction());
},[dispatch])

export default userAction();





