import React from 'react'

const UsersData = ({data}) => {
  return (
    <div>
      <h1>Display users data</h1>
      {
        data.map(x=>{
          return(
            <>
              <li>{x}</li>
            </>
          )
        })
      }

    </div>
  )
}

export default UsersData
