import "./App.css";
import { useSelector } from "react-redux";
import UsersData from "./components/UsersData";

function App() {
  let userslist = useSelector((state) => state.userList);
  const { loading, users, error } = userslist;
  console.log(userslist);

  return (
    <div className="App">
      <h1>React Redux with Thunk Middleware</h1>
      {loading ? (
        <h1>Loading....</h1>
      ) : error ? (
        <h1>Error in Data</h1>
      ) : (
        <UsersData data={users} />
      )}
    </div>
  );
}

export default App;
