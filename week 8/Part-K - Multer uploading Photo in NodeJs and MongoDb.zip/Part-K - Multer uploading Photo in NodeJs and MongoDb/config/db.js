import mongoose from "mongoose";
import colors from 'colors'

const dbConnection = async() =>{
    try {
        await mongoose.connect("mongodb://127.0.0.1:27017/usersData")
        console.log(`Database connected`.bgMagenta.white)
    } catch (error) {
        console.log(`Error in Connection`.bgRed.white)
    }
}

export default dbConnection; 