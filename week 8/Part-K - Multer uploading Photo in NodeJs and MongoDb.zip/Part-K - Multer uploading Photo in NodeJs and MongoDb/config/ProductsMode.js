import mongoose from "mongoose";

const productSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    image: {
        data: Buffer,
        contentType: String
    }
})

export default mongoose.model("product",productSchema)