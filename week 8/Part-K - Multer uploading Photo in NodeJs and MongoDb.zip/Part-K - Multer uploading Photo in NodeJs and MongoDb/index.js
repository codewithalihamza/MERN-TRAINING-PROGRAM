import express from "express";
import bodyParser from "body-parser";
import dbConnection from "./config/db.js";
import multer from "multer";
import colors from "colors";

import ProductsMode from "./config/ProductsMode.js";
const port = 5000;

// database connection
const app = express();

dbConnection();

// json conversion

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

const Storage = multer.diskStorage({
  destination: "uploads",
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

const upload = multer({
  storage: Storage,
})

// posting image to MongoDb
app.post("/uploadpic",upload.single("testImg"), async(req,res)=>{
   new ProductsMode({name: req.body.name,
    image:{ data: req.file.filename,
        contentType: "image/png"}
   }).save();
})


// app.post("/uploadpic",upload.single("testImg"), async(req,res)=>
// {
//    await new ProductsMode({
//     name: req.body.name,
//     image:{
//         data: req.file.filename,
//         contentType: "image/jpg"
//     }
//    }).save();

// })

// posting image to MongoDb
// app.post("/uploadpic",(req,res)=>{
//     upload(req,res,(err)=>{
//         if(err){
//             console.log("error in uploading")
//         }else{
//            let newPhoto =  new ProductsMode({
//                 name: req.body.name,
//                 image:{
//                     data: req.file.filename,
//                     contentType: "jpg/png/jpeg"
//                 }
//             })
//             newPhoto.save().then(()=>{console.log("saved").catch(err=>console.log(err))
//             })
//         }
//     })

// })

//testing route
app.get("/", (req, res) => {
  console.log("hello on consol");
});

// Listening port on Server
app.listen(port, () => {
  console.log(`Server is running at port ${port}`.bgGreen);
});
