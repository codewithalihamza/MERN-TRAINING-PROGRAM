import React from 'react'

const Cart = () => {
  return (
    <div>
      <h1>Cart Page</h1>
    </div>
  )
}

export default Cart
