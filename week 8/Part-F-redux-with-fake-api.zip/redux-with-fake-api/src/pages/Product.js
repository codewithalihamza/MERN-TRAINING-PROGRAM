import React, { useState, useEffect } from 'react'

import { useParams } from 'react-router-dom'

const Product = () => {

const {id} = useParams();

const [prod, setProd] = useState([]);
  const [loading, setLoading] = useState(false);

const getSingleProduct = async () => {
  setLoading(true);
  let res = await fetch(`https://fakestoreapi.com/products/${id}`);
  res = await res.json();
  setProd(res);
  setLoading(false);
  console.log(prod);
};

useEffect(()=>{
  getSingleProduct()
},[])


const LoadingComp = () => {
  return (
    <>
      <div
        style={{ width: "12rem", height: "12rem" }}
        className=" spinner-border text-primary"
        role="status"
      >
        <span className="visually-hidden">Loading...</span>
      </div>
    </>
  );
};


const ShowSingleProduct = () =>{
  return(
    <>

        <div className='col-md-6'>
          <img src={prod.image} width={400} height={400} />
          <p className='text-start'>{prod.description}</p>
        </div>


        <div className='col-md-6'>

          <h1 className='fs-1 text-start fw-bold'>{prod.title}</h1>
          <hr />
          <h3 className='text-start lead'>{prod.description}</h3>
          <h4 className='display-4 fw-bold text-start'>Rs. {prod.price}</h4>
          
          <p className='fw-bold fs-3 text-start'>Ratings: {prod.rating && prod.rating.rate}
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>
                <i className="fa-solid fa-star"></i>

          </p>

          <hr />

          <button className='btn btn-outline-dark btn-lg'>Add to Cart</button>
          <button className='btn btn-dark btn-lg ms-2'>Go to Cart</button>

        </div>
    </>
  )
}







  return (
    <div className='container py-5'>
        <div className='row py-4'>
          {loading ? <LoadingComp /> : <ShowSingleProduct />}
        </div>
    </div>
  )
}

export default Product
