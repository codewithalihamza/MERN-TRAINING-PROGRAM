import { ADD_TO_CART, REMOVE_FROM_CART, EMPTY_CART } from "./constant"

// action file here


export const addItem = () =>{
    return{
        type: ADD_TO_CART,
        payload
    }
}

export const removeItem = () =>{
    return{
        type: REMOVE_FROM_CART,
        payload
    }
}

export const emptyCart = () =>{
    return{
        type: EMPTY_CART,
        payload
    }
}