import { ADD_TO_CART, REMOVE_FROM_CART, EMPTY_CART } from "./constant"

// cart reducer here
const cartItems = []

const cartReducerComp = (state = cartItems, action) =>{

    switch(action.type){
        case ADD_TO_CART:
            return 10

        case REMOVE_FROM_CART:
            return 100

        case EMPTY_CART:
            return 1000

        default: 
            return state
    }
}

export default cartReducerComp