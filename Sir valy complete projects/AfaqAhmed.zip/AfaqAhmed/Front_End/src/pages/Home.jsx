import React from 'react'
import Features from '../components/Features'
import HomeAbout from '../components/HomeAbout'
import Slider from '../components/Slider'

const Home = () => {
  return (
    <>
      <Slider />
      <HomeAbout />
      <Features />
    </>
  )
}

export default Home
