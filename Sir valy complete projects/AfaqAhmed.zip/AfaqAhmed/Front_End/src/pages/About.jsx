import React from 'react'
import HomeAbout from '../components/HomeAbout'

const About = () => {
  return (
    <div className='mt-32'>
      <HomeAbout />
    </div>
  )
}

export default About
