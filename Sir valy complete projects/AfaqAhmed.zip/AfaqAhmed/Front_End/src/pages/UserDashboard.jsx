import React from "react";
import { Route, Routes } from "react-router-dom";
import ActivityList from "../components/ActivityList";
import AddActivity from "../components/AddActivity";
import BMICalculator from "../components/BMICalculator";
import ContactTrainer from "../components/ContactTrainer";
import SideMenuUserDashboard from "../components/SideMenuUserDashboard";
import UserFeedback from "../components/UserFeedback";

const UserDashboard = ({myFunc}) => {

  return (
    <div>
      <div className="mt-20">
        <div>
          <div>
            <section>
              <SideMenuUserDashboard myFunc={myFunc}/>
            </section>
            <div className="p-4 sm:ml-64">
              <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
                <Routes>
                  <Route path="/my-activities" element={<ActivityList myFunc={myFunc}/>}></Route>
                  <Route path="/add-activity" element={<AddActivity myFunc={myFunc}/>}/>
                  <Route path="/contact-trainer" element={<ContactTrainer />}/>
                  <Route path="/bmi-calculator" element={<BMICalculator />}/>
                  <Route path="/feedback" element={<UserFeedback />}/>
                </Routes>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
