import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";


const MobileMenu = ({token}) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const logIn = token !== null && token !== undefined;
    setIsLoggedIn(logIn);
    console.log(isLoggedIn)
    console.log(token)
  }, [token]);

  return (
    <div>
      <ul className="flex flex-col space-y-7 items-center">
        <li className="w-40 text-center py-3 text-sm cursor-pointer border-2 border-red-700 rounded-full text-white bg-lightBlack">
          <Link
            to="/about"
            activeClass="text-red-400"
            spy={true}
            smooth={true}
            offset={-100}
            duration={700}
          >
            about
          </Link>
        </li>
        <li className="w-40 text-center py-3 text-sm cursor-pointer border-2 border-red-700 rounded-full text-white bg-lightBlack">
          <Link
            to="/trainers"
            activeClass="text-red-400"
            spy={true}
            smooth={true}
            offset={-100}
            duration={700}
          >
            trainers
          </Link>
        </li>
        {
          !isLoggedIn ?
        <li className="w-40 text-center py-3 text-sm cursor-pointer border-2 border-red-700 rounded-full text-white bg-lightBlack">
          <Link
            to="/login"
            activeClass="text-red-400"
            spy={true}
            smooth={true}
            offset={-100}
            duration={700}
          >
            Login
          </Link>
        </li>
        :
        <li className="w-40 text-center py-3 text-sm cursor-pointer border-2 border-red-700 rounded-full text-white bg-lightBlack">
          <Link
            to="/user-dashboard/my-activities"
            activeClass="text-red-400"
            spy={true}
            smooth={true}
            offset={-100}
            duration={700}
          >
            Dashboard
          </Link>
        </li>

        }
      </ul>
    </div>
  );
};

export default MobileMenu;
