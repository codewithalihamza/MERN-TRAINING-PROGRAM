import React from "react";
import TrainerCard from "./TrainerCard";

const ContactTrainer = () => {
  const db = [
    {
      image: "/photos/Trainer01.jpg",
      title: "Abdullah Karim",
      description:
        "He is a well experienced trainer. He has been in Dubai for around two complete years. There he is working as a trainer and also diet planner.",
      experience: "2 Years Experience",
      mode: "Online",
      mail: 'abdullahkarim@gmail.com'
    },
    {
      image: "/photos/Trainer02.jpg",
      title: "Ayesha Akram",
      description:
        "She has established his own gym. SHe is also an international trainer with more than 50 overseas clients. She has a 100% track record in training ladies to become smart and well looking. SHe is also famous for her skin and hair tricks",
      experience: "6 Months Experience",
      mode: "Online",
      mail: 'ayeshaakram@gmail.com'
    },
    {
      image: "/photos/Trainer03.jpg",
      title: "Junaid Ahmed",
      description:
        "He is a professional who helps clients achieve their fitness goals through personalized exercise and nutrition plans. He is typically knowledgeable in areas such as strength training, cardio, and weight management, and proper exercise ",
      experience: "1.5 Years Experience",
      mode: "Online",
      mail: 'junaidahmed@gmail.com'
    },
    {
      image: "/photos/Trainer04.jpg",
      title: "Zainab Iftikhar",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fug",
      experience: "2 hours",
      mode: "Online",
      mail: 'zainabiftikhar@gmail.com'
    },
  ];

  return (
    <div>
      <h1 className={` text-center text-4xl font-bold mb-5`}>Gym Trainers</h1>
      {
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {db.map((activity) => (
            <TrainerCard activity={activity} />
          ))}
        </div>
      }
    </div>
  );
};

export default ContactTrainer;
