import React, { useState } from "react";
import { FiEdit2 } from "react-icons/fi";
import { MdOutlineDelete } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const ActivityCard = ({ activity, myFunc, setEditBox, setFormData, fetchData}) => {
  const navigate = useNavigate();
  const [token, setToken] = useState(null)
  const { image, title, description, duration, date, _id } = activity;

  const onDelete = async (id) => {
    try {
      console.log(id)
      const tkn =  sessionStorage.getItem("token");
      setToken(tkn);
      console.log(token);
      if(!token) {
        toast.error("Please wait a sec to reset token");
        return;
      }
      let res = await fetch(
        `http://127.0.0.1:5000/api/activity/activitydelete/${id}`,
        {
          method: "delete",
          headers: new Headers({
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          }),
        }
      );
      res = await res.json();
      console.log(res)
      if (res.msg === "error") {
        if (res.error.includes("token") || res.error.includes("expire")) {
          sessionStorage.clear();
          myFunc();
          window.location.reload();
        }
        throw new Error(res.error);
      } else {
        toast.success('Activity is deleted successfully')
        fetchData()
      }
    } catch (error) {
      toast.error(error);
      console.log(error)
    }
  };

  const onEdit = async(id) => {
    try {
      const tkn = sessionStorage.getItem("token");
      setToken(tkn);
      if(!token){
        toast.error("Please wait a sec to reset token");
        return;
      }
      const userId = sessionStorage.getItem("userId");
      console.log(userId);
      let res = await fetch(
        `http://127.0.0.1:5000/api/activity/get-single/${id}`,
        {
          method: "GET",
          headers: new Headers({
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          }),
        }
      );
      res = await res.json();
      if (res.msg === "error") {
        console.log(res)
        if (res.error.includes("token") || res.error.includes("expire")) {
          sessionStorage.clear();
          myFunc();
          window.location.reload();
        }
        throw new Error(res);
      } else {
        setEditBox(true)
        setFormData(res)
      }
    } catch (error) {
      toast.error(error.error);
      console.log(error);
    }
  };
  return (
    <div>
      <div className="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
        <img className="rounded-t-lg" src={image} alt="" />
        <div className="p-5">
          <div className="flex justify-between mb-1 items-center">
            <p className="text-sm font-bold text-red-400">{duration} min</p>
            <p className="text-sm font-bold text-red-400">{date}</p>
          </div>
          <h5 className="mb-2 text-2xl font-bold tracking-tight text-slate-300">
            {title}
          </h5>
          <p className="mb-3 font-normal text-gray-400">{description}</p>
          <div className="flex justify-between mt-1 items-center">
            <FiEdit2 className="text-lg text-gray-400 cursor-pointer hover:text-white duration-200 ease-in-out" onClick={() => onEdit(_id)} />
            <MdOutlineDelete
              className="text-2xl text-gray-400 cursor-pointer hover:text-white duration-200 ease-in-out"
              onClick={() => onDelete(_id)}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActivityCard;
