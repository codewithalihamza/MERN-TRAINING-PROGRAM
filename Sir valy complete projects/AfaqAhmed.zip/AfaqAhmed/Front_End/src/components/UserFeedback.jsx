import React from "react";

const UserFeedback = () => {
  return (
    <div>
      User Feedback
    </div>
  );
};

export default UserFeedback;
