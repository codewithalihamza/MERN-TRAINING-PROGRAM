import React from "react";

export default function Spinner() {
  return (
    <div
      className="flex flex-col justify-center items-center fixed top-0 bottom-0 right-0 left-0 z-50 bg-black
    bg-opacity-50"
    >
      <img src="/photos/logo.png" alt="loading..." className="h-40 block" />
      <p>Please Wait ...</p>
    </div>
  );
}
