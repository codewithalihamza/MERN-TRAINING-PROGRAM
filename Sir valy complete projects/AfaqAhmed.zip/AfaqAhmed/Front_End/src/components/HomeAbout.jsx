import React from "react";

const HomeAbout = () => {
  return (
    <div className="md:h-screen max-w-5xl px-4 mx-auto flex flex-col-reverse md:flex-row mt-10 md:space-x-10">
      <div>
        <img src="/photos/pic04.jpg" alt="" />
      </div>
      <div className="md:mt-10 mb-10 md:mb-0">
        <p className="text-red-700 font-semibold mt-3">Information about us</p>
        <p className="text-slate-800 font-bold text-3xl"><span className="text-red-700 font-extrabold">AONE</span> - an online gym platform with activity tracker facility</p>
        <p className="text-gray-600 text-sm mt-10">
          If you're looking for a convenient and effective way to stay active
          and fit from the comfort of your own home, online gym training and
          activity tracking could be just what you need. With online gym
          training, you have access to professional trainers who can guide you
          through workouts tailored to your fitness goals and preferences. And
          with an activity tracker, you can monitor your progress and stay
          motivated to reach your fitness goals.
        </p>
        <ul className="mt-10 text-sm font-semibold tracking-widest text-gray-900 list-disc ml-5">
            <li><p>Activity Track</p></li>
            <li className="my-2"><p>Free Training</p></li>
            <li><p>Online meetings with trainers</p></li>
        </ul>
      </div>
    </div>
  );
};

export default HomeAbout;
