import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import ActivityCard from "./ActivityCard";
import Spinner from "./Spinner";

const ActivityList = ({ myFunc }) => {
  const [editBox, setEditBox] = useState(false);
  const [token, setToken] = useState("");
  const [activities, setActivities] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    id: sessionStorage.getItem('userId'),
    title: "",
    duration: 1,
    date: "",
    description: "",
  }
  );
  const { title, duration, date, description } = formData;

  const fetchData = async () => {
    try {
      console.log('fetching data')
      const userId = sessionStorage.getItem("userId");
      let res = await fetch(
        `http://127.0.0.1:5000/api/activity/get-all/${userId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      res = await res.json();
      console.log(res)
      if (res.msg === "error") {
        if (res.error.includes("token") || res.error.includes("expire")) {
          sessionStorage.clear();
          myFunc();
          window.location.reload();
        }
        throw new Error(res);
      } else {
        console.log('setting activities')
        setActivities(res);
        setLoading(false);
      }
    } catch (error) {
      toast.error(error.error);
      console.log(error.error);
    }
  };
  useEffect(() => {
    console.log('hello world')
    fetchData();
  }, []);

  const handleOnChange = (e) => {
    setFormData({
    ...formData,
      [e.target.id]: e.target.value,
    });
  };
  const handeOnUpdate = async(e) => {
    e.preventDefault();
    try {
      if(title === "Default"){
        alert("Please select the activity title");
      } else {
        const tkn = sessionStorage.getItem("token");
        setToken(tkn);
        if(!token) {
          toast.error("Please wait a sec and then edit the activity");
          return;
        }
        console.log(formData)
        let res = await fetch(`http://127.0.0.1:5000/api/activity/activityupdate/${formData._id}`, {
          method: "put",
          headers: new Headers({
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }),
          body: JSON.stringify(formData),
        });
        res = await res.json();
        if(res.msg === 'error') {
          console.log(res)
          if(res.error.includes('token') || res.error.includes('expire')){
            sessionStorage.clear();
            myFunc()
          }
          throw new Error(res)
        } else {
          toast.success('Edited Successfully');
          fetchData()
          setEditBox(false);
        }
      }
    } catch (error) {
      toast.error(error.error)
      console.log(error)
    }
  };

  if (loading) {
    return <Spinner />;
  }

  return (
    <div>
      <h1 className={` text-center text-4xl font-bold mb-5`}>My Activities</h1>
      {!activities.length && (
        <p className="mt-10 text-center">No activities to show</p>
      )}
      {activities && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {activities.map((activity) => (
            <ActivityCard activity={activity} myFunc={myFunc} setEditBox={setEditBox} setFormData={setFormData} fetchData={fetchData}/>
          ))}
        </div>
      )}
      {editBox && (
        <form onSubmit={handeOnUpdate}>
          <div className="md:flex mb-6">
            <div className="md:w-1/3">
              <label
                className="block text-gray-600 font-bold md:text-left mb-3 md:mb-0 pr-4"
                htmlFor="title"
              >
                Activity Title
              </label>
            </div>
            <div className="md:w-2/3">
              <select
                className="form-select block w-full focus:bg-white"
                id="title"
                onChange={handleOnChange}
              >
                <option value="Default">Default</option>
                <option value="run">Run</option>
                <option value="swim">Swim</option>
                <option value="run and Hike">Run and Hike</option>
                <option value="bicycle ride">Bicycle Ride</option>
              </select>
              <p className="py-2 text-sm text-gray-600">choose your activity</p>
            </div>
          </div>
          <div className="md:flex mb-6">
            <div className="md:w-1/3">
              <label
                className="block text-gray-600 font-bold md:text-left mb-3 md:mb-0 pr-4"
                htmlFor="duration"
              >
                Activity Duration
              </label>
            </div>
            <div className="md:w-2/3">
              <input
                className="form-input block w-full focus:bg-white"
                id="duration"
                type="number"
                value={duration}
                onChange={handleOnChange}
                required={true}
                min="1"
              />
              <p className="py-2 text-sm text-gray-600">
                add the duration of activity in minutes
              </p>
            </div>
          </div>
          <div className="md:flex mb-6">
            <div className="md:w-1/3">
              <label
                className="block text-gray-600 font-bold md:text-left mb-3 md:mb-0 pr-4"
                htmlFor="my-textfield"
              >
                Activity Date
              </label>
            </div>
            <div className="md:w-2/3">
              <input
                className="form-input block w-full focus:bg-white"
                id="date"
                type="date"
                value={date}
                onChange={handleOnChange}
                required={true}
              />
              <p className="py-2 text-sm text-gray-600">
                add the date of the activity
              </p>
            </div>
          </div>
          <div className="md:flex mb-6">
            <div className="md:w-1/3">
              <label
                className="block text-gray-600 font-bold md:text-left mb-3 md:mb-0 pr-4"
                htmlFor="my-textarea"
              >
                Activity Description
              </label>
            </div>
            <div className="md:w-2/3">
              <textarea
                className="form-textarea block w-full focus:bg-white"
                id="description"
                value={description}
                rows={8}
                onChange={handleOnChange}
                required={true}
              />
              <p className="py-2 text-sm text-gray-600">
                add description of you activity
              </p>
            </div>
          </div>
          <div className="md:flex md:items-center">
            <div className="md:w-1/3" />
            <div className="md:w-2/3">
              <button
                className="shadow bg-yellow-700 hover:bg-yellow-500 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded"
                type="submit"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};

export default ActivityList;
