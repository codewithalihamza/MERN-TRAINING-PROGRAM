import React from 'react'
import ContactTrainer from './ContactTrainer'

const Trainers = () => {
  return (
    <div className='max-w-7xl mt-36 px-10 mx-auto'>
      <ContactTrainer />
    </div>
  )
}

export default Trainers
