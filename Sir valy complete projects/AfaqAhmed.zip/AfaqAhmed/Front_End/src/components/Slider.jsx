import React from "react";
import SwiperCore, {
  Navigation,
  Pagination,
  Autoplay,
} from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css/bundle";

export default function Slider() {
  SwiperCore.use([Autoplay, Navigation, Pagination]);

  const slides = [
    {
      id: '1',
      image: '/photos/pic01.jpg',
      title: `Shape your perfect body`,
      // title2: ``,
      quote: 'If you do not find the time, if you do not do the work, you do not get the results.'
    },
    {
      id: '2',
      image: '/photos/pic02.jpg',
      title: 'Track your workout activity',
      quote: 'Dead last finish is greater than did not finish, which trumps did not start.'
    },
    {
      id: '3',
      image: '/photos/pic03.jpg',
      title: 'Get workout plans for free',
      quote: 'Push harder than yesterday if you want a different tomorrow.'
    }
  ]
  return (
    <>
        <Swiper
          className="h-screen"
          modules={[Navigation, Pagination, Autoplay]}
          slidesPerView={1}
          navigation
          autoplay={{ delay: 3000 }}
        >
          {slides.map((slide) => (
            <SwiperSlide key={slide.id} className="w-full h-full">
              {/* <div className="relative bg-black" >
                <img src={slide.image} alt="" className="w-full h-full opacity-50"/>
                <div className="absolute top-24 left-3 sm:top-36 sm:left-16 md:top-40 md:left-24 lg:top-56 lg:left-32 text-white max-w-xl">
                  <p className="font-bold text-lg xs:text-2xl sm:text-5xl md:text-6xl tracking-wider">{slide.title}</p>
                  <p className="text-gray-300 mt-5 xs:mt-7 sm:mt-10 text-md italic">{slide.quote}</p>
                  <button className="mt-5 xs:mt-14 sm:mt-20 px-3 py-1 xs:px-4 sm:px-5 xs:py-2 sm:py-2 bg-red-600 hover:bg-red-900 ease-in-out duration-200 text-sm sm:text-lg">
                    Read More
                  </button>
                </div>
              </div> */}
              <div className="w-full h-full" style={{
                backgroundImage: `url(${slide.image})`,
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center',
                backgroundAttachment: 'fixed',
              }}>
                <div className="bg-black bg-opacity-70 h-full">
                <div className=" text-white max-w-6xl mx-auto pt-96 lg:pt-[22rem] px-14 base:px-16 lg:px-0">
                  <p className="font-bold text-2xl base:text-3xl xs:text-4xl sm:text-5xl tracking-wider">{slide.title}</p>
                  <p className="text-gray-300 mt-7 base:mt-10 text-md italic">{slide.quote}</p>
                  <button className="mt-7 base:mt-10  px-5 py-2 bg-red-600 hover:bg-red-900 ease-in-out duration-200 text-md base:text-lg">
                    Read More
                  </button>
                </div>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
    </>
  );
}
