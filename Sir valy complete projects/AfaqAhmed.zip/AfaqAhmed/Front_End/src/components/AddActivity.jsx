import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const AddActivity = ({myFunc}) => {
  const [token, setToken] = useState('')
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    id: sessionStorage.getItem('userId'),
    title: "",
    duration: 1,
    date: "",
    description: "",
  }
  );
  const { title, duration, date, description } = formData;

  useEffect(() => {
    const tkn = sessionStorage.getItem('token')
    setToken(tkn)
  }, [])

  const handleOnChange = (e) => {
    setFormData({
    ...formData,
      [e.target.id]: e.target.value,
    });
  };

  const handleOnSubmit = async(e) => {
    e.preventDefault();
    try {
      if(title === "Default"){
        alert("Please select the activity title");
      } else {
        let res = await fetch("http://127.0.0.1:5000/api/activity/add", {
          method: "POST",
          headers: new Headers({
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }),
          body: JSON.stringify(formData),
        });
        res = await res.json();
        if(res.msg === 'error') {
          if(res.error.includes('token') || res.error.includes('expire')){
            sessionStorage.clear();
            myFunc()
            window.location.reload();
          }
          throw new Error(res)
        } else {
          toast.success(res.msg);
          navigate("/user-dashboard/my-activities");
        }
      }
    } catch (error) {
      toast.error(error.error)
      console.log(error.error)
    }
  };

  return (
    <div>
      <div id="section2" className="p-8 mt-6 lg:mt-0 rounded shadow bg-white">
        <form onSubmit={handleOnSubmit}>
          <div className="md:flex mb-6">
            <div className="md:w-1/3">
              <label
                className="block text-gray-600 font-bold md:text-left mb-3 md:mb-0 pr-4"
                htmlFor="title"
              >
                Activity Title
              </label>
            </div>
            <div className="md:w-2/3">
              <select
                className="form-select block w-full focus:bg-white"
                id="title"
                onChange={handleOnChange}
              >
                <option value="Default">Default</option>
                <option value="run">Run</option>
                <option value="swim">Swim</option>
                <option value="run and Hike">Run and Hike</option>
                <option value="bicycle ride">Bicycle Ride</option>
              </select>
              <p className="py-2 text-sm text-gray-600">choose your activity</p>
            </div>
          </div>
          <div className="md:flex mb-6">
            <div className="md:w-1/3">
              <label
                className="block text-gray-600 font-bold md:text-left mb-3 md:mb-0 pr-4"
                htmlFor="duration"
              >
                Activity Duration
              </label>
            </div>
            <div className="md:w-2/3">
              <input
                className="form-input block w-full focus:bg-white"
                id="duration"
                type="number"
                value={duration}
                onChange={handleOnChange}
                required= {true}
                min="1"
              />
              <p className="py-2 text-sm text-gray-600">
                add the duration of activity in minutes
              </p>
            </div>
          </div>
          <div className="md:flex mb-6">
            <div className="md:w-1/3">
              <label
                className="block text-gray-600 font-bold md:text-left mb-3 md:mb-0 pr-4"
                htmlFor="my-textfield"
              >
                Activity Date
              </label>
            </div>
            <div className="md:w-2/3">
              <input
                className="form-input block w-full focus:bg-white"
                id="date"
                type="date"
                value={date}
                onChange={handleOnChange}
                required= {true}
              />
              <p className="py-2 text-sm text-gray-600">
                add the date of the activity
              </p>
            </div>
          </div>
          <div className="md:flex mb-6">
            <div className="md:w-1/3">
              <label
                className="block text-gray-600 font-bold md:text-left mb-3 md:mb-0 pr-4"
                htmlFor="my-textarea"
              >
                Activity Description
              </label>
            </div>
            <div className="md:w-2/3">
              <textarea
                className="form-textarea block w-full focus:bg-white"
                id="description"
                value={description}
                rows={8}
                onChange={handleOnChange}
                required= {true}
              />
              <p className="py-2 text-sm text-gray-600">
                add description of you activity
              </p>
            </div>
          </div>
          <div className="md:flex md:items-center">
            <div className="md:w-1/3" />
            <div className="md:w-2/3">
              <button
                className="shadow bg-yellow-700 hover:bg-yellow-500 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded"
                type="submit"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddActivity;
