import React, { useEffect, useState } from "react";
import { BiMenu } from "react-icons/bi";
import { NavLink } from "react-router-dom";
import MobileMenu from "./MobileMenu";

export default function Header({ token }) {
  const [mobileMenu, setMobileMenu] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const logIn = token !== null && token !== undefined;
    setIsLoggedIn(logIn);
    console.log(isLoggedIn)
    console.log(token)
  }, [token]);

  console.log(token)
  console.log(isLoggedIn);
  return (
    <header
      className="border-red-700 shadow-sm z-30 rounded-full text-white border-2 w-headerW fixed top-3 bg-myblack uppercase"
      style={{ left: "50%", transform: "translate(-50%, 0)" }}
    >
      <div className="flex justify-between items-center px-3">
        <div>
          <NavLink to="/">
            <img
              src="/photos/logo.png"
              alt="Logo"
              className="h-12 cursor-pointer my-2"
            />
          </NavLink>
        </div>
        <div className="hidden md:block">
          <ul className="flex space-x-7 items-center">
            <li className="px-2 text-sm cursor-pointer tracking-widest">
              <NavLink
                to="/"
                activeClass="text-white"
                className={({ isActive }) =>
                  isActive ? "text-white" : "text-gray-400"
                }
              >
                home
              </NavLink>
            </li>
            <li className="px-2 text-sm cursor-pointer tracking-widest">
              <NavLink
                to="/about"
                className={({ isActive }) =>
                  isActive ? "text-white" : "text-gray-400"
                }
              >
                about
              </NavLink>
            </li>
            <li className="px-2 text-sm cursor-pointer tracking-widest">
              <NavLink
                to="/trainers"
                className={({ isActive }) =>
                  isActive ? "text-white" : "text-gray-400"
                }
              >
                trainers
              </NavLink>
            </li>
            {isLoggedIn ? (
              <li>
                <NavLink to={"/user-dashboard/my-activities"}>
                  <button class="bg-yellow-500 hover:bg-white text-black py-3 px-12 rounded-full text-xs uppercase ease-in-out duration-300">
                    dashboard
                  </button>
                </NavLink>
              </li>
            ) : (
              <li>
                <NavLink to="/login">
                  <button class="bg-yellow-500 hover:bg-white text-black py-3 px-12 rounded-full text-xs uppercase ease-in-out duration-300">
                    Log in
                  </button>
                </NavLink>
              </li>
            )}
          </ul>
        </div>
        <div className="md:hidden py-3 text-2xl">
          <span className="sr-only">Open menu</span>
          <BiMenu
            onClick={() => {
              setMobileMenu(!mobileMenu);
            }}
          />
        </div>
      </div>
      <div className="fixed top-24 right-10 block md:hidden">
        {mobileMenu && <MobileMenu token={token}/>}
      </div>
    </header>
  );
}
