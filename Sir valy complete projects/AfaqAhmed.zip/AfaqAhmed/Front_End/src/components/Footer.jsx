import React from "react";
import { Link, useNavigate } from "react-router-dom";

const Footer = () => {
  const navigate = useNavigate();
  return (
    <div className="mt-20">
      <div className="flex flex-col w-full md:flex-row">
        <div className="relative w-full">
          <img src="/photos/FooterImg01.jpg" alt="" className="h-96 w-full" />
          <div className="absolute top-28 left-10 z-20 text-white">
            <p className="font-bold text-4xl">Contact us Now</p>
            <p className="my-7 md:my-10">
              If you trust us on your jouney, please contact us at
              aoneplanners@gmail.com
            </p>
            <button
              className="bg-orange-500 px-5 py-2 rounded text-lg hover:bg-orange-700 duration-200 ease-in-out"
              onClick={() => navigate("/login")}
            >
              Get Started
            </button>
          </div>
        </div>
        <div className="relative w-full">
          <img
            src="/photos/FooterImg02.jpg"
            alt=""
            className="h-96 w-full z-0"
          />
          <div className="absolute top-28 left-10  text-white z-20">
            <p className="font-bold text-4xl">Free Planning App</p>
            <p className="my-7 md:my-10">
              Get started now, surely you will be happy
            </p>
            <button
              className="bg-orange-500 px-5 py-2 rounded text-lg hover:bg-orange-700 duration-200 ease-in-out"
              onClick={() => navigate("/login")}
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
        <div>
          <div className="bg-myblack">
            <div className="w-full container mx-auto p-4 md:px-6 md:py-8">
              <div className="sm:flex sm:items-center sm:justify-between">
                <Link
                  to="/"
                  className="flex items-center mb-4 sm:mb-0"
                >
                  <img
                    src="/photos/logo.png"
                    className="h-10 mr-3"
                    alt=""
                  />
                  <span className="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">
                    AONE Planners
                  </span>
                </Link>
                <ul className="flex flex-wrap items-center mb-6 text-sm text-gray-500 sm:mb-0 dark:text-gray-400">
                  <li>
                    <Link to="/about" className="mr-4 hover:underline md:mr-6 ">
                      About
                    </Link>
                  </li>
                  <li>
                    <Link to="/trainers" className="mr-4 hover:underline md:mr-6">
                      Trainers
                    </Link>
                  </li>
                </ul>
              </div>
              <hr className="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
              <span className="block text-sm text-gray-500 sm:text-center dark:text-gray-400">
                © 3{" "}
                <a href="https://flowbite.com/" className="hover:underline">
                  AONE-Planners™
                </a>
                . All Rights Reserved.
              </span>
            </div>
          </div>
        </div>
    </div>
  );
};

export default Footer;
