import React from "react";

const Features = () => {
  return (
    <div className="w-full md:h-[30rem]flex flex-col md:flex-row overflow-hidden mt-20">
      <div className="w-full h-full border border-black">
        <img src="/photos/pic05.jpg" alt="" className="h-full" />
      </div>
      <div className="w-full flex text-gray-300 overflow-hidden bg-[#141414]">
        <div className="h-full w-full justify-between flex flex-col py-10 bg-[#1E1E1E] px-3 overflow-hidden">
          <div>
            <p className="text-white text-2xl font-bold tracking-wide mb-2 overflow-hidden">Planning</p>
            <p>
              It helps to identify our goals clearly. It makes us decide clearly
              and concretely what we need to do effectively and timely.
            </p>
          </div>
          <div>
            <p className="text-white text-2xl font-bold tracking-wide mb-2 overflow-hidden">Running</p>
            <p>
              It helps to build strong bones, as it is a good exercise.
              strengthen muscles. improve cardiovascular fitness. burn kilojoules.
            </p>
          </div>
        </div>
        <div className="h-full w-full justify-between flex flex-col py-10 bg-[#141414] px-3 overflow-hidden">
          <div>
            <p className="text-white text-2xl font-bold tracking-wide mb-2 overflow-hidden">Bicycling</p>
            <p>
              Cycling can help to protect you from serious diseases such as
              stroke, heart attack, some cancers, depression, diabetes and obesity.
            </p>
          </div>
          <div>
            <p className="text-white text-2xl font-bold tracking-wide mb-2 overflow-hidden">Swimming</p>
            <p>
              builds endurance, muscle strength and cardiovascular fitness.
              helps you maintain a healthy weight, healthy heart and lungs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features;
