import React, { useState } from "react";
import {
  AiFillCloseCircle,
  AiOutlineLogout,
  AiFillCalculator,
} from "react-icons/ai";
import { HiOutlineMenuAlt1 } from "react-icons/hi";
import {
  MdFeedback,
  MdSportsKabaddi,
  MdOutlineEventNote,
} from "react-icons/md";
import { SlNotebook } from "react-icons/sl";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const SideMenuUserDashboard = ({myFunc}) => {
  const [sidebar, setSideBar] = useState(false);
  const navigate = useNavigate();

  const handleLogOut = () => {
    sessionStorage.clear();
    if (!sessionStorage.getItem("token")) {
      navigate("/login");
      toast.success("Logged out successfully");
      myFunc();
    } else {
      toast.error("There was an error logging out.");
    }
  };
  return (
    <section className="z-50">
      <span
        className="text-4xl cursor-pointer"
        onClick={() => setSideBar(!sidebar)}
      >
        <HiOutlineMenuAlt1 className="ml-3 mt-3" />
      </span>
      <nav
        className={`${
          !sidebar && "hidden"
        } sm:block fixed top-0 left-0  w-64 h-screen transition-transform -translate-x-0`}
      >
        <div
          className="h-full px-3 py-4 overflow-y-auto bg-gray-800 pt-28"
          data-te-sidenav-menu-ref
        >
          <ul className="space-y-2">
            <li className="flex p-2 text-base font-normal  rounded-lg text-white justify-between items-center">
              <div className="flex items-center">
                <svg
                  aria-hidden="true"
                  className="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z" />
                  <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z" />
                </svg>
                <span className="ml-3">Dashboard</span>
              </div>
              <div>
                <AiFillCloseCircle
                  className="sm:hidden text-lg"
                  onClick={() => setSideBar(!sidebar)}
                />
              </div>
            </li>
            <li>
              <Link
                to="/user-dashboard/my-activities"
                className="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <SlNotebook className="text-xl text-gray-400" />
                <span className="flex-1 ml-3 whitespace-nowrap">
                  My Activities
                </span>
              </Link>
            </li>
            <li>
              <Link
                to="/user-dashboard/add-activity"
                className="flex items-center p-2 text-base font-normal  rounded-lg text-white hover:bg-gray-700"
              >
                <MdOutlineEventNote className="text-xl text-gray-400" />
                <span className="flex-1 ml-3 whitespace-nowrap">
                  Add Activitiy
                </span>
              </Link>
            </li>
            <li>
              <Link
                to="/user-dashboard/contact-trainer"
                className="flex items-center p-2 text-base font-normal rounded-lg text-white hover:bg-gray-700"
              >
                <MdSportsKabaddi className="text-xl text-gray-400" />
                <span className="flex-1 ml-3 whitespace-nowrap">
                  Gym Trainers
                </span>
              </Link>
            </li>
            <li>
              <Link
                to="/user-dashboard/bmi-calculator"
                className="flex items-center p-2 text-base font-normal text-white hover:bg-gray-700 rounded-lg"
              >
                <AiFillCalculator className="text-xl text-gray-400" />
                <span className="flex-1 ml-3 whitespace-nowrap">
                  BMI Calculator
                </span>
              </Link>
            </li>
            <li>
              <Link
                to="/user-dashboard/feedback"
                className="flex items-center p-2 text-base font-normal text-white hover:bg-gray-700 rounded-lg"
              >
                <MdFeedback className="text-xl text-gray-400" />
                <span className="flex-1 ml-3 whitespace-nowrap">Feedback</span>
              </Link>
            </li>
            <li
              className="flex items-center p-2 text-base font-normal text-white hover:bg-gray-700 rounded-lg cursor-pointer"
              onClick={handleLogOut}
            >
              <AiOutlineLogout className="text-xl text-gray-400" />
              <span className="flex-1 ml-3 whitespace-nowrap">Log Out</span>
            </li>
          </ul>
        </div>
      </nav>
    </section>
  );
};

export default SideMenuUserDashboard;


