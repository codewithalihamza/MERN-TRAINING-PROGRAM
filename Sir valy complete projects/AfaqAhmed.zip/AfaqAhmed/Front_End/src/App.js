import {  useEffect, useState } from "react";
import { Route, Routes } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Footer from "./components/Footer";
import Header from "./components/Header";
import PrivateRoute from "./components/PrivateRoute";
import Trainers from "./components/Trainers";
import About from "./pages/About";
import Home from "./pages/Home";
import Login from "./pages/Login";
import SignUp from "./pages/Signup";
import UserDashboard from "./pages/UserDashboard";

function App() {
  const [token, setToken] = useState(null);
  
  useEffect(() => {
    const tkn = sessionStorage.getItem("token");
    setToken(tkn);
  }, []);
  
  const myFunc = () => {
    const tkn = sessionStorage.getItem("token");
    setToken(tkn);
  }

  return (
    <div>
      <Header token={token} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login myFunc={myFunc} />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/trainers" element={<Trainers />} />
        <Route path="/about" element={<About />} />
        <Route path="/user-dashboard/" element={<PrivateRoute />}>
          <Route path="/user-dashboard/*" element={<UserDashboard myFunc={myFunc}/>} />
        </Route>
      </Routes>
        <Footer />

      <ToastContainer
        position="bottom-center"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
      />
    </div>
  );
}

export default App;
