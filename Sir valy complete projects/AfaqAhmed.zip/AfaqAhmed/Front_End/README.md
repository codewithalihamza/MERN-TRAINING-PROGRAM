# Task to create the frontend of a website in React

The technologies used in this task are react and tailwind css
