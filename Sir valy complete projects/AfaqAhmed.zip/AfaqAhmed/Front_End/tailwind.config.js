module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
    colors:{
      'myblack': '#1B1B1B',
      'lightBlack': '#282828'
    },
    width: {
      'headerW': '97%'
    },
    height: {
      'box2': '100px',
      'box3': '100%'
    },
    screens: {
      'lg': '1110px',
      // 'md': '860px',
      // 'sm': '643px',
      'xs': '470px',
      'base': '397px'
    }
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
};