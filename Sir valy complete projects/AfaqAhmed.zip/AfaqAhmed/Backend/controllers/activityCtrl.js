const activity = require("../models/activityModel");

const addActivity = async (req, res) => {
  try {
    let newActivity = await activity(req.body);
    newActivity.save();
    res.json({
      msg: "Activity is created successfully",
    });
  } catch (error) {
    res.json({ msg: "error", error: error });
  }
};

const getAllActivity = (req, res) => {
  activity
    .find({id: req.params.id})
    .then((activity) => {
      res.json(activity);
    })
    .catch((err) => {
      res.json({ msg: "error", error: err });
    });
};

const getActivity = (req, res) => {
  activity
    .findById(req.params.id)
    .then((activity) => {
      res.json(activity);
    })
    .catch((err) => {
      res.json({ msg: "error", error: err });
    });
};

const updateActivity = async(req, res) => {
  try {
    let response = await activity.findByIdAndUpdate(req.params.id, req.body, {new: true});
    res.send(response);
  } catch (err) {
    res.json({ msg: "error", error: err });
  }
};

const deleteActivity = async (req, res) => {
  const deleteActivityData = await activity.findByIdAndRemove(
    req.params.id
  );
  res.send(deleteActivityData);
}

module.exports = {
  addActivity,
  getAllActivity,
  deleteActivity,
  getActivity,
  updateActivity
};
