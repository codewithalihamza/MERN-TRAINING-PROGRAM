const userModel = require("../models/userModel");
const { generateToken } = require("../config/jwToken");
const validateMongoDbId = require("../utils/validateMongoDbId");
const jwt = require("jsonwebtoken");
const env = require("dotenv").config();

const createUser = async (req, res) => {
  try {
    let email = req.body.email;
    let findUser = await userModel.findOne({ email: email });

    if (!findUser) {
      let newUser = await userModel(req.body);
      newUser.save();
      res.json({
        msg: "User created successfully",
        id: newUser._id,
        email: newUser?.email,
        name: newUser?.name
      });
    } else {
      res.json({ msg: "error", error: 'User is already existed' });
    }
  } catch (error) {
    res.json({ msg: 'error', error: error});
  }
};
const loginUser = async (req, res) => {
  try {
    let { email, password } = req.body;
    let findUser = await userModel.findOne({ email: email });
    if (findUser && (await findUser.isPasswordMatched(password))) {
      res.json({
        msg: 'login successful',
        id: findUser?._id,
        email: findUser?.email,
        name: findUser?.name,
        token: generateToken(findUser?._id),
      });
    } else {
      res.json({msg: 'error', error: 'Invalid credentials'});
    }
  } catch (error) {
    res.json({ msg: 'error', error: error });
  }
};

const getAllUsers = async (req, res) => {
  try {
    let users = await userModel.find();
    res.json(users);
  } catch (error) {
    throw new Error(error);
  }
};
const getSingleUser = async (req, res) => {
  const { id } = req.params;
  validateMongoDbId(id);
  try {
    let user = await userModel.findById(id);
    res.json(user);
  } catch (error) {
    throw new Error(error);
  }
};
const deleteUser = async (req, res) => {
  const { id } = req.params;
  validateMongoDbId(id);
  try {
    let user = await userModel.findByIdAndDelete(id);
    res.json(user);
  } catch (error) {
    throw new Error(error);
  }
};
const blockuser = async (req, res) => {
  try {
    const { id } = req.params;
    validateMongoDbId(id);
    const blockUser = await userModel.findByIdAndUpdate(
      id,
      {
        isBlocked: true,
      },
      {
        new: true,
      }
    );
    res.json({
      message: "User is blocked",
    });
  } catch (error) {
    throw new Error(error);
  }
};
const unblockuser = async (req, res) => {
  try {
    const { id } = req.params;
    validateMongoDbId(id);
    const unblockUser = await userModel.findByIdAndUpdate(
      id,
      {
        isBlocked: false,
      },
      {
        new: true,
      }
    );
    res.json({
      message: "User is unblocked",
    });
  } catch (error) {
    throw new Error(error);
  }
};

module.exports = {
  createUser,
  loginUser,
  getAllUsers,
  getSingleUser,
  deleteUser,
  blockuser,
  unblockuser,
};
