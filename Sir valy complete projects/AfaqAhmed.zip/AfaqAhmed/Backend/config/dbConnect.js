const mongoose = require('mongoose');
const env = require('dotenv').config();

const dbConnect = () => {
    try {
        mongoose.connect(process.env.dbUrl)
        console.log('DB connection established')
    } catch (error) {
        console.log('DB connection error')
    }
}

module.exports = dbConnect;