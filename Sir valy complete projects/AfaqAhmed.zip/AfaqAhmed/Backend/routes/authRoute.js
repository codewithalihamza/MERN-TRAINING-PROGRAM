const express = require('express');
const { createUser, loginUser, getAllUsers, getSingleUser, deleteUser, blockuser, unblockuser } = require('../controllers/userCtrl');
const { authMiddleware, adminMiddleware } = require('../middlewares/authMiddleware');

const router = express.Router();

router.post('/register', createUser)
router.post('/login', loginUser)
// router.get('/all-users', authMiddleware, adminMiddleware, getAllUsers)
// router.get('/:id', authMiddleware, adminMiddleware, getSingleUser)
// router.delete('/:id', deleteUser)
// router.put('/block-user/:id', authMiddleware, adminMiddleware, blockuser)
// router.put('/unblock-user/:id', authMiddleware, adminMiddleware, unblockuser)

module.exports = router;