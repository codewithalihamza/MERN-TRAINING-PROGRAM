const express = require('express');
const { addActivity, getAllActivity, deleteActivity, getActivity, updateActivity } = require('../controllers/activityCtrl');
const { authMiddleware } = require('../middlewares/authMiddleware');
const router = express.Router();

router.post('/add', authMiddleware,  addActivity)
router.get('/get-all/:id',  getAllActivity)
router.get('/get-single/:id', authMiddleware,  getActivity)
router.delete("/activitydelete/:id", authMiddleware, deleteActivity);
router.put("/activityupdate/:id", authMiddleware, updateActivity);

module.exports = router;