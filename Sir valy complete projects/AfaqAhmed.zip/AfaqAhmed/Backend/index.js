const bodyParser = require('body-parser');
const express = require('express');
const dbConnect = require('./config/dbConnect');
const authRouter = require('./routes/authRoute');
const activityRouter = require('./routes/activityRoute');
const {handleError, notFound} = require('./middlewares/errorHandler');
const env = require('dotenv').config();
const cookieParser = require('cookie-parser');
// const morgan = require('morgan')
const cors = require('cors');
const app = express();

dbConnect();
const PORT = process.env.PORT || 4000
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(cookieParser());
// app.use(morgan('dev'))
const corsOptions = {
    origin: "*",
    credentials: true, //access-control-allow-credentials:true
    optionSuccessStatus: 200,
  };
app.use(cors(corsOptions))

app.use('/api/user', authRouter)
app.use('/api/activity', activityRouter)

app.listen(PORT, () => {
    console.log(`Server is started at ${PORT}`)
})