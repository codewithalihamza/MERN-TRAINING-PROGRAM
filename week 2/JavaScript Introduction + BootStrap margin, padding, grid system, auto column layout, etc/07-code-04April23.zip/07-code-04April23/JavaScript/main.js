// console.log("Hello World...!!")
// console.log("Welcome to Game Train")
// let aName = "Sameer";
// console.log(aName)

// primitives / basic data types

/*
numbers, 
string
boolean
null 
undefined
NAN - Not a number

*/

// non-primitives / user defined / advanced

/*
    arrays, 
    objects
    nested arrays 
    arrays of objects 
    functions     

*/