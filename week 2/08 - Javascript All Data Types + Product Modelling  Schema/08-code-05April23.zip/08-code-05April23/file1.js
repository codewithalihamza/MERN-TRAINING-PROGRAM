// Data types in JavaScript 
// Primitives DT
// String, number, yes / no (boolean)


// var un = "Ali Aslam";
// console.log("My namne is " + un);


// var name = "Aslam";
// var age = 21; 
// var edu = "MCS";
// var isActive = true;

// console.log("My name"  + name);
// console.log("age"  + age);
// console.log("Education"  + edu);
// console.log("enrollment status"  + isActive);




// var name = "Aslam";
// var age = 21; 
// var edu = "MCS";
// var isActive = true;

// console.log("My name"  
// + name + " age "  + age 
// + " Education "  + edu +
//  " enrollment status "  
//  + isActive);


// var stu1 = "Awais"
// var stu2 = "Fayyaz"
// var stu3 = "Masood"
// var stu4 = "Momina"
// var stu4 = "Qazi"


// // 0,  1,    2,   3,   4   
// var abc = ["A", "B", "C", "D", "E"]
// console.log(" 0 index " + abc[0] + " 3 index " + abc[3]);


// 0,  1,    2,   3,   4   
// var abc = ["A", "B", "C", "D", "E"]
// console.log(abc[0] + " " + abc[1]);


// var marks = [45, 65, 77, 88, 100]; 
// console.log(marks[3]);


// var marks = [45, 65, 77, 88, 100, 111]; 
// console.log(marks.length);


// ===========Object in JavaScript====





var products = 
[
    {
        pId: 1, 
        pName: "Unstitched Silver BD-2601",
        price: 29750,  
        color: ["red", "blue", "peach"],
        desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
        countInStock: 30,
        comments: {
            uid:111,
            uName: "ali",
            desc: "nice product",
            ratings: 4,
            isApproved: false,
        },

        isAvailable: true,
        isOnSale: false
    },
    {
        pId: 2, 
        pName: "stiched arabian",
        price: 12000,  
        color: ["white","red", "blue", "peach"],
        desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
        countInStock: 2,
        isAvailable: true,
        isOnSale: true
    },
    {
        pId: 3, 
        pName: "new witner",
        price: 16000,  
        color: ["blue", "peach", "magenta"],
        desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
        countInStock: 7,
        isAvailable: true,
        isOnSale: false
    },
]

console.log(products[0].comments.uName);
console.log(products[0].comments.ratings);
// console.log(products[1].color[1]);





// var product = 
// {
//     pId: 1, 
//     pName: "Unstitched Silver BD-2601",
//     price: 29750,  
//     color: ["red", "blue", "peach"],
//     desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
//     countInStock: 30,
//     isAvailable: true,
//     isOnSale: false
// }
// console.log(product.color[1]);


// var product = 
// {
//     pId: 1, 
//     pName: "Unstitched Silver BD-2601",
//     price: 29750,  
//     color: "Peach",  
//     desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
//     countInStock: 30,
//     isAvailable: true,
//     isOnSale: false
// }
// console.log(product.pId);
// console.log(product.pName);
// console.log(product.price);




// var product = 
// {
//     pId: 1, 
//     pName: "Unstitched Silver BD-2601",
//     price: 29750,  
//     color: "Peach",  
//     desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
//     countInStock: 30,
//     isAvailable: true,
//     isOnSale: false
// }
// console.log(product);















//          // 0,  1,    2,   3,   4   
// var abc = ["A", "B", "C", "D", "E"]
// // console.log(abc);
// console.log(abc[2]);
// console.log(abc[4]);
// console.log(abc[0]);
// console.log(abc);





//                 // 0,    1,        2,       3,        4   
// var students = ["Awais","Fayyaz","Masood","Momina","Qazi"]

// var abc = ["A", "B", "C", "D", "E"]

// console.log(students);
// console.log(abc);




// var un = "Imran Shabbir";
// var marks = 450;
// var isPass = true


// console.log(un);
// console.log(marks);
// console.log(isPass);










// var b = 10; 




// var x = 10;

// var b = 10; 
// let b = 10; 
// const b = 10; 

// var y = "10";
// var a = "*$#/="
// var z = true;





// Non-primitives
// arrays, objects, function










// // console.log("Hello");


// ap kaisy hain aj ?
// am fine =    text / string

// a = "10"
// b = 10
// c = a + b

// yes + 10




// 1010110

// 1101110

// int x = 10
// int x = 10001111

// a=127         4bit
// b=12800000    8bit
// c=1564647954  16bit



// date ? 
// 05-04-2023   date   

// time ?       
// 02:30       time


// mobile ? 
// 3229900800  number
//             integer

// age ?       
// 35          number
//             number 
//             integer


// Yes / No    evaluation
// No
// 1  /  0
// true / false



