// create an admin panel on console 

// username = ?
// password:

// admin
    /*
        He has full access
        He can Edit Record
        He can view Record
        He can update Record
        He can delete Record 
        He can assign new users
        Even he can change Database
    */
// teacher

/*
        Teacher can only update subjects
        Teacher can add marks
        Teacher can take attendance
        Teacher can assign assignments
        Teacher can modify record up to certain levels
    */
// student

/*
        Student can view his / her marks
        Student can view his / her detail
        ............... can check his / her grades
        .........can submit assignments         
    */
// also handle edge cases

// create a fast food menu 


// var result = 330;
// if(result){
//     console.log("yes")
// }else{
//     console.log("no")
// }



// var result = 330;
// if(result==330){
//     console.log("yes")
// }else{
//     console.log("no")
// }



// var marks = 440;
// marks>=450 ? console.log("A Grade") : console.log("B Grade")


// if(marks>=450)
// {
//     console.log("A Grade")
// }
// else
// {
//     console.log("B Grade")
// }

// var age = 18;
// var gender = "male";

// if(age>=18){
//     if(gender=="male"){
//         console.log("continental marriage is awsome idea")
//     }else{
//         console.log("Search a lawyer or imam masjid")
//     }
// }
// else{
//     console.log("------Disclaimer-------");
//     console.log("you cannot marry")
//     console.log("Dua Zahra case will not be helpful")
//     console.log("Bs aik hi solution hai, job dhondo")
//     console.log("-------------------------")
// }


// create a calculator 
// result sheet 




// conditional statements 
/*
if
if else
nested if
ladder if 
ternary operator (short if)
short circuit operator
*/


// var age = 81

// if(age>=18 && age<=60){
//     console.log("You serve in Govt.")
//     console.log("You can caste vote.")
//     console.log("You can drive.")
//     console.log("You can do the following operators")
// }
// else if(age>60 && age<=80){
//     console.log("Ghar beth kr tasbeeh kro")
// }
// else if(age>80){
//     console.log("Ab bas aur nahi")
// }
// else{
//     console.log("Abhi apk khelny kodny k din hain")
// }









// var age = 17

// if(age>=18)
// {
//     console.log("You can drive")
// }
// else
// {
//     console.log("sakoon se ghar betho")
// }




// var x = 6; 
// var y = 7; 
// console.log(`The value of ${x} and 
// value of y is ${y}`)







// =================
// operators in javaScrtip 

// arithmatic, 
// +, -, *, /, % (modulous / remainder)

// var x = 10; 
// var y = 3; 
// console.log(x+y)

// var x = 10; 
// var y = 3; 
// var z = x+y
// console.log("The sum of x and y is : " + z)



// var x = 10; 
// var y = 3; 
// var z = x-y
// console.log("The difference : " + z)




// var x = 10; 
// var y = 3; 
// var z = x*y
// console.log("mulitplication : " + z)




// var x = 20; 
// var y = 4; 
// var z = x/y
// console.log("division : " + z)


// var x = 10; 
// var y = 3; 
// var z = x%y
// console.log(z)


// var x = 17; 
// var y = 3; 
// var z = x%y
// console.log(z)




// comparison 
// =, ==, ===, !=, >, <, >=, <=

// var x = 5;
// var y = 5; 

// console.log(x>=y);


// var x = 4;
// var y = 5; 

// console.log(x!=y);


// var x = "5"; 
// var y = 5;
// var stat = true

// console.log(typeof x)
// console.log(typeof y)
// console.log(typeof stat)



// var x = 5;
// var y = 5; 

// console.log(x===y);





// logical 

// And && - OR || - Not !

// var x = 6; 
// var y = 7; 
// var z = 10;
// console.log(!(x<y || z<x))



// unary operator
// ++, 
// x = x+1; 
// x++
// --



// var x = 12; 
// // postfix = baad main add krna 
// // x = x+1;
// // x++ 
// // console.log(x++);
// // console.log(x);
// console.log(++x);
// console.log(x);








// var products = [
// {
//     pId: 1, 
//     pName: "Unstitched Silver BD-2601",
//     price: 29750,  
//     color: ["red", "blue", "peach"],
//     desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
//     countInStock: 30,
//     comments: [
//         {
//             uid:111,
//             uName: "ali",
//             desc: "nice product",
//             ratings: 4,
//             isApproved: false,
//         },
//         {
//             uid:222,
//             uName: "danish",
//             desc: "faulty product",
//             ratings: 1.0,
//             isApproved: false,
//         },
//         {
//             uid:333,
//             uName: "afzaal",
//             desc: "average product",
//             ratings: 3.5,
//             isApproved: false,
//         },
//         {
//             uid:444,
//             uName: "awais",
//             desc: "excellent product",
//             ratings: 5,
//             isApproved: false,
//         },
//     ],

//     isAvailable: true,
//     isOnSale: false
// },
// // ---------------------
// {
//     pId: 2, 
//     pName: "stiched arabian",
//     price: 12000,  
//     color: ["white","red", "blue", "peach"],
//     desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
//     countInStock: 2,
//     comments: [
//         {
//             uid:111,
//             uName: "imran",
//             desc: "normal product",
//             ratings: 4,
//             isApproved: false,
//         },
//         {
//             uid:222,
//             uName: "masood",
//             desc: "not satisfied",
//             ratings: 3,
//             isApproved: false,
//         },
//     ],
//     isAvailable: true,
//     isOnSale: true
// },
// {
//     pId: 3, 
//     pName: "new witner",
//     price: 16000,  
//     color: ["blue", "peach", "magenta"],
//     desc: "ONLY AVAILABLE FOR PRE-ORDER AT THE MOMENT, WILL BE SHIPPED POST 6TH APRIL.",
//     countInStock: 7,        
//     comments: [
//         {
//             uid:111,
//             uName: "hamza",
//             desc: "good product",
//             ratings: 4,
//             isApproved: false,
//         },
//         {
//             uid:222,
//             uName: "junaid",
//             desc: "nice satisfied",
//             ratings: 4.5,
//             isApproved: false,
//         },
//         {
//             uid:333,
//             uName: "amjad",
//             desc: "average and substandard product",
//             ratings: 3.5,
//             isApproved: false,
//         },
//     ],
//     isAvailable: true,
//     isOnSale: false
// },

// ]
// ratings
// console.log(products[0].comments[1].uName)
// console.log(products[0].comments[1].ratings)
// console.log(products[0].comments[0].ratings)
// console.log(products[0].comments.lengt)



// console.log(products[0].comments)
// console.log(products[0].comments.uName)
// console.log(products[0].comments.ratings)

// console.log(products[2].color[2])


// console.log(products[0].comments.uName);
// console.log(products[0].comments.ratings);
// console.log(products[1].color[1]);

