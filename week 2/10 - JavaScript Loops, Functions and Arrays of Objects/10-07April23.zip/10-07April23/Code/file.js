
// var x = 10; 
// var y; 

// console.log(typeof x)
// console.log(typeof y)

// console.log(x+y);

// function sum(x = 0, y = 0)
// {
//     console.log(x+y)
// }
// sum(10);


// var abc = [34, 5, 77, 84, 77]
// make sum of complete array


// function 

// double arguments 

// function sum(x, y)
// {
//     console.log(x+y)
// }
// sum(45, 10);

// function sum(x, y, z)
// {
//     console.log(x+y+z)
// }
// sum(45, 10, 5);


// function sum(x, y)
// {
//     console.log(x-y)
// }
// sum(45, 10);


// function sum(x)
// {
//    if(x>50){
//         console.log(x+5)
//    }
//    else{
//     console.log(x)
//    }
// }
// sum(49);











// simple functions

// function msg(){
//     console.log("Welcome to Dashboard")
// }
// msg();
// msg();
// msg();
// msg();

// one parameter function / parametrized function 


// function displayMsg(){
//     console.log("Welcome To KFC")
//     console.log("---------------")
//     console.log("[1]. Pizza")
//     console.log("[2]. Burger")
//     console.log("[3]. Shawarma")
//     console.log("[4]. Sandwich")
// }
// displayMsg();

// function bonusSalary(x){
//     console.log(x+500)
// }
// bonusSalary(50000)
// bonusSalary(45000)
// bonusSalary(72000)












// functoin fName()
// {
//     logic / sytax / code
// }
// fName() // function calling





// var num = [45, 33, 42]

// arrays method 

// add element at the end of array
// console.log(num)

// num.push(100)

// console.log(num)


// remove element from the end of array

// console.log(num)
// num.pop()
// num.pop()
// console.log(num)

// add element at the beggining of array


// console.log(num)

// num.unshift(10)

// console.log(num)

// console.log(num)


// remove element from the beggining of array

// console.log(num)
// num.shift();
// console.log(num)

// console.log(num)


// add element at any position 

// var num = [45, 33, 42, 55, 77]; 
// num.splice(2,1)
// console.log(num)

// var num = [45, 33, 42, 55, 77]; 
// num.splice(2,1,100)
// console.log(num)
// num.splice(2,0,111)
// console.log(num)



// remove element from any position





// var num = [45, 33, 42, 66, 99]
// var exp = ["a", "b", "a", "c", "a", "b"]




// for (let i = 1; i<=4; i++) {

//     for(let j = 1; j<=2; j++){
//         console.log("A")        
//     }

//     console.log("------------")
// }





// var students = [
//     {
//         rollNo: 101,
//         sName: "Ghulam Hussain",
//         age: 21,
//         course: ["C++", "Java", "C Sharp"],
//         fee: 2500000,
//         isActive: false
//     },
//     {
//         rollNo: 102,
//         sName: "Umar Aman Ullah",
//         age: 20,
//         course: ["Swift", "Java", "Python", "AI", "MERN"],
//         fee: 1200000,
//         isActive: true
//     },
//     {
//         rollNo: 103,
//         sName: "Muhammad Ali Qazi",
//         age: 26,
//         course: ["WordPress", "Php", "MySql", "MERN", "Figma"],        
//         fee: 200000,
//         isActive: false
//     },
//     {
//         rollNo: 104,
//         sName: "Muhammad Awais",
//         age: 23,
//         course: ["AI", "NFT", "BlockChain", "MetaVerse"],        
//         fee: 200000,
//         isActive: false
//     },

// ]


// for(var i = 0; i<students.length; i++){
//     if(students[i].course == "BCS"){
//         console.log(" Student Name is : " + students[i].sName)
//     }
// }

// for(var i = 0; i<students.length; i++){
//     console.log(students[i])
// }


// create a login and password 
// with max 3 tries


// Loops 


// var cities = ["LHR", "ISB", "KAR", "MTN"];

// var i = 6;
// do{
//     console.log(i);
//     i++
// }while(i<5);



// for(var i = 0; i<marks.length;i++){
    //     console.log(marks[i])
    // }

// var cities = ["LHR", "ISB", "KAR", "MTN"];

// var i = 0;
// while(i<cities.length){
//     console.log(cities[i]);
//     i++
// }





// var cities = ["LHR", "ISB", "KAR", "MTN"];


// cityName is the cleanest city in Pakistan

// for(var i = 0; i<cities.length; i++){
//     if(cities[i]=="ISB")
//     {
//         console.log(cities[i] + " is the cleanest city");
//     }
//     else
//     {
//         console.log(cities[i])
//     }
// }





// var marks = [33, 32, 68, 45, 79, 88];
            //43, 42,    55, 

// for(var i = 0; i<marks.length; i++){
//     if(marks[i]<=50)
//     {
//         console.log(marks[i]+10);
//     }
//     else
//     {
//         console.log(marks[i])
//     }
// }




// var marks = [33, 32, 68, 45, 79, 88, 100, 99];
// console.log(marks.length);
// console.log(marks[2])


// for(var i = 0; i<marks.length;i++){
//     console.log(marks[i])
// }



// console.log(marks[0])
// console.log(marks[1])
// console.log(marks[2])
// console.log(marks[3])
// console.log(marks[4])




// for(var a = 1; a<=10; a++)
// {
//     console.log("2" + " * "  + a + " = " + (a*2) )
// }



// for(var a = 0; a<=5; a++)
// {
//     console.log(a)
// }
//a value = 0, 1, 2, 3, 4, 5
//print =   0, 1, 2, 3, 4, 5
//increment = 1, 2, 3, 4, 5





// for(initialValue, condition, increment/dec)
// {
//     code / logic / syntax
// }






// LOGICAL & DSA QUIZ
// Cohort-6 (Game Train)
// MERN BootCamp
// ========================


// let products = [

//     {
//         id: 1,
//         name: 'Shark Ultra',
//         totalRatings: 126,
//         oldPrice: 699,
//         newPrice: 230,
//         variations: [
            
//             {
//                 id: 101,
//                 color: 'black',
//                 price: '240',
//                 qty: 12,
//                 status: false,
//             },
//             {
//                 id: 102,
//                 color: 'gray',
//                 price: '220',
//                 qty: 0,
//                 status: true,
//             },
//             {
//                 id: 103,
//                 color: 'silver',
//                 price: '250',
//                 qty: 7,
//                 status: true,
//             },            
            
//         ],
//         brand: 'shark',
//         desc: 'INCREDIBLE SUCTION AND SONIC MOPPING: First, it’s an ultra-powerful whole home vacuum on carpets and floors that empties its own dustbin.',
//         comments: [
//             {
//                 uId: 111,
//                 name: "ali",
//                 subj: "Good Product",
//                 desc: "I purchase this product which is find good",
//                 date: "28-11-2022",
//                 rating: 4.5,
//                 isApproved: false
//             },
//             {
//                 uId: 222,
//                 name: "faisal",
//                 subj: "Faulty Product",
//                 desc: "I am not satisfied with Product Quality",
//                 date: "26-10-2022",
//                 rating: 2,
//                 isApproved: false
//             },
//             {
//                 uId: 333,
//                 name: "nasir",
//                 subj: "Nice Product",
//                 desc: "Amazon providing standarized products",
//                 date: "26-10-2022",
//                 rating: 5,
//                 isApproved: false
//             },

//         ],
//         countInStock: 19,
//         isAvailble: false

//     },
// // -------------------
//     {
//         id: 2,
//         name: 'LED TV',
//         totalRatings: 150,
//         oldPrice: 75000,
//         newPrice: 70000,
//         variations: [
            
//             {
//                 id: 101,
//                 color: 'white',
//                 price: '65000',
//                 qty: 2,
//                 status: true,
//             },
//             {
//                 id: 102,
//                 color: 'gray',
//                 price: '68000',
//                 qty: 1,
//                 status: true,
//             },
//             {
//                 id: 103,
//                 color: 'black',
//                 price: '80000',
//                 qty: 18,
//                 status: true,
//             },            
            
//         ],
//         brand: 'tv',
//         desc: 'INCREDIBLE SUCTION AND SONIC MOPPING: First, it’s an ultra-powerful whole home vacuum on carpets and floors that empties its own dustbin.',
//         comments: [
//             {
//                 uId: 1111,
//                 name: "ahmad",
//                 subj: "Average Product",
//                 desc: "An average product provided to me",
//                 date: "10-02-2022",
//                 rating: 3.5,
//                 isApproved: false
//             },
//             {
//                 uId: 2222,
//                 name: "shumail",
//                 subj: "Faulty Product",
//                 desc: "Ever experience Amazon is not providing best quality products",
//                 date: "05-03-2022",
//                 rating: 2,
//                 isApproved: false
//             },
//             {
//                 uId: 3333,
//                 name: "toufeeq",
//                 subj: "Good Product",
//                 desc: "A good product is available with Amazon",
//                 date: "14-10-2022",
//                 rating: 5,
//                 isApproved: false
//             },
//             {
//                 uId: 4444,
//                 name: "aslam",
//                 subj: "averageProduct",
//                 desc: "An average product in quality",
//                 date: "14-10-2022",
//                 rating: 3,
//                 isApproved: false
//             },

//         ],
//         countInStock: 21,       
//         isAvailble: true         

//     },

//     {
//         id: 3,
//         name: 'Samsung',
//         totalRatings: 40,
//         oldPrice: 340000,
//         newPrice: 332000,
//         variations: [
            
//             {
//                 id: 101,
//                 color: 'white',
//                 price: '340000',
//                 qty: 10,
//                 status: true,
//             },
//             {
//                 id: 102,
//                 color: 'gray',
//                 price: '305000',
//                 qty: 2,
//                 status: true,
//             },
//             {
//                 id: 103,
//                 color: 'black',
//                 price: '335000',
//                 qty: 12,
//                 status: true,
//             },            
            
//         ],
//         brand: 'mobile',
//         desc: 'INCREDIBLE SUCTION AND SONIC MOPPING: First, it’s an ultra-powerful whole home vacuum on carpets and floors that empties its own dustbin.',
//         comments: [
//             {
//                 uId: 100,
//                 name: "imran",
//                 subj: "Average Product",
//                 desc: "An average product provided to me",
//                 date: "24-05-2022",
//                 rating: 4,
//                 isApproved: false
//             },
//             {
//                 uId: 101,
//                 name: "hassan",
//                 subj: "Product",
//                 desc: "Amazon is not providing best quality products",
//                 date: "15-07-2022",
//                 rating: 2.5,
//                 isApproved: false
//             },          

//         ],
//         countInStock: 24,       
//         isAvailble: true         

//     },
    
// ]


// 1. How many people have given comments, print their names as well.
// 2. Sum all products rating, then draw an average of all products
        // Ultra average rating is ???
        // LED average rating is ??
        // this should be done in one loop
        // options you can use functions / loops, if conditions and anything required to achieve the task.
// 3. Product name (Ultra / LED) has total rating ??? and average ratings ???
// 4. if stock of any product reach to zero convert its status from true to false.
// 5. Total available stock (countInStock) of all products 
// 6. total price of all stock (new price)
// 7. Place all items on sale, analyze all factors by himself / herself, Think critically to solve the problem.
// 8. Which product is higher in rating amongst all products, print the name and price of that category as well.
// 9. How many products are available in gray colors, print their name and new price.
//10. If rating is greater than or equal to 4, please convert its status from false to true. 

//===============================================
