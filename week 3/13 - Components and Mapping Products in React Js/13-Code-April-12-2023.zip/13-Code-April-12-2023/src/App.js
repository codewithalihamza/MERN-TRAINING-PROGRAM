// import logo from './logo.svg';
import './App.css';
import Store from './components/Store';
// import NavBar from './components/NavBar';
// import StudentsRecord from './components/StudentsRecord';

const App = () => {
  
  

  return (
    <div className="App">

    <Store />


      {/* <NavBar />
      <StudentsRecord />      */}
     
      
    </div>
  );
}

export default App;
