import React from 'react'
import {productsDB} from './products'

const Store = () => {
  return (
    <div>
        <h1>Store File</h1>
        <div className='container'>
            <div className='row'>
            
        {
            productsDB.map(sPro =>{
                
                return(
                    <div className='col-lg-3 col-md-6 col-sm-12 mt-4'>
                        <div className="card" style={{width: '18rem'}}>
                        <img src={sPro.image} className="card-img-top" height={350} width={200} alt="..." />
                        <div className="card-body">
                            <h5 className="card-title">{sPro.title.slice(0,15)}...</h5>
                            <p className="card-text">{sPro.price}</p>
                            <a href="#" className="btn btn-outline-dark">Add to Cart</a>
                        </div>
                    </div>
    
                    </div>    
                )
            })
        }
        </div>
        </div>
    </div>
  )
}

export default Store
