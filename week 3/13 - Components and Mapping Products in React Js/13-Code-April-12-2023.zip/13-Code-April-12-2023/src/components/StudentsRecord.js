import React from 'react'

const StudentsRecord = () =>{

    let students = [
        {
          userName: "Muhammad Awais",
          pic: "./images/user1.png",
          age: 20,
          enroll: true
        },
        {
          userName: "Hamza",
          pic: "./images/user2.webp",
          age: 21,
          enroll: false
        },
        {
          userName: "Masood",
          pic: "./images/user3.jpg",
          age: 22,
          enroll: true
        },
        {
          userName: "Shoaib",
          pic: "./images/user4.webp",
          age: 23,
          enroll: false
        },
    
      ]
    return(
        <>
            <h1>Students Data</h1>            
            <hr />
            <div className='container'>
                <div className='row'>

                {
                students.map(stu =>{
                    const {userName, enroll, pic} = stu;
                    if(stu.enroll)
                return(
                    <div className='col-lg-3 col-md-6 col-12'>
                        <div className="card" style={{width: "18rem"}}>
                            <img src={pic} className="card-img-top" alt="..." />
                            <div className="card-body">
                                <h5 className="card-title">Student Name: {userName}</h5>
                                <p className="card-text">Enroll Status {enroll.toString()}</p>
                                <a href="#" className="btn btn-primary">Save Record</a>
                            </div>
                        </div>
                    </div>
                )
                })
                }  


                </div>
            </div>  
        </>
    )
}

export default StudentsRecord
