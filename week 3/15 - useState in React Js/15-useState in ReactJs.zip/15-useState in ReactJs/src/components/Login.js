import React, {useState} from 'react'

const Login = () => {
    const[btn, setBtn] = useState(false)

    const[txtColor, setTxtColor] = useState("black")

    const changeHandler = () =>{
        setBtn(!btn)        
    }
    const colorHandler = () =>{
        setTxtColor(!txtColor);
    }
return (
    <div>        
        {btn && 
        <h1 style={{color: txtColor ? "red" : "black"}}>Welcome to Dashboard</h1>
        }
        <button onClick={changeHandler}>
            {btn ? "Logout" : "Login"}
        </button>

        <button onClick={colorHandler}>Color Control</button>




        {/* <button onClick={changeBtn}>
            {btn ? "Login" : "Logout"}
        </button> */}
    </div>
  )
}

export default Login
