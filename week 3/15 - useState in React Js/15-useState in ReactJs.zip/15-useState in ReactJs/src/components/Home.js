import React from 'react'
import {useState} from 'react';


const Home = () => {

    const[age, setAge] = useState(25)
 


    const msg = () =>{        
        setAge(age+1)        
    }



  return (
    <div>
        <h1>Age is : {age}</h1>

        <button onClick={msg}>Click Me</button>

        


    </div>
  )
}

export default Home
