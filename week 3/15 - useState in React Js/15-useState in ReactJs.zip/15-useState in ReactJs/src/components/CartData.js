import React, { useState } from 'react'
const CartData = () => {
    const [inc, setInc] = useState(0)
    // const abc = () =>{
    //     setInc(inc+1)
    // }
    const decHandler = () =>{
        setInc(inc-1)
    }
    let price = 5000;
  return (


    <div>        
        <h1>Cart Data</h1>
        <button onClick={() =>{setInc(inc+1)}}>+</button>
        {inc}
        <button onClick={decHandler}>-</button>
        <h1>Total Bill : {price*inc}</h1>
    </div>
    // <div>        
    //     <h1>Cart Data</h1>
    //     <button onClick={abc}>+</button>
    //     {inc}
    //     <button onClick={decHandler}>-</button>
    //     <h1>Total Bill : {price*inc}</h1>
    // </div>
  )
}

export default CartData
