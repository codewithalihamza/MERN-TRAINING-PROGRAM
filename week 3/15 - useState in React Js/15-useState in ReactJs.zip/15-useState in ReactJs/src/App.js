import './App.css';
import CartData from './components/CartData';
import Login from './components/Login';
// import Home from './components/Home';

function App() {
  return (
    <div className="App">
      <Login />
      {/* <CartData /> */}
      {/* <Home /> */}
    </div>
  );
}

export default App;
