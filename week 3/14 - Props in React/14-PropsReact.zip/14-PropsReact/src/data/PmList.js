const ListDB = [
    {
        id: 1,
        pName: "Nawaz Sharif",
        pic: "./photos/pic1.jpg",
        desig: "PM - PML"
    },
    {
        id: 2,
        pName: "Imran Khan",
        pic: "./photos/pic2.jpg",
        desig: "PM - PTI"
    },
    {
        id: 3,
        pName: "Asif Ali Zardari",
        pic: "./photos/pic3.jpg",
        desig: "PM - PPP"
    },
    {
        id: 4,
        pName: "Fazal ur Rehman",
        pic: "./photos/pic4.png",
        desig: "Dream PM - PDM"
    },
]
export default ListDB;


