import React from 'react'

const SCardDesign = ({name}) => {
  return (    
    <div className='col-lg-3 col-md-6 col-sm-12 mt-4'>
        <div className="card" style={{width: '18rem'}}>
            <img src={name.pic} className="card-img-top" height={350} width={200} alt="..." />
            <div className="card-body">
                <h5 className="card-title">{name.pName}...</h5>
                <p className="card-text">{name.desig}</p>
                <a href="#" className="btn btn-warning">Please Caste Vote</a>
            </div>
        </div>
    </div>
    
  )
}

export default SCardDesign
