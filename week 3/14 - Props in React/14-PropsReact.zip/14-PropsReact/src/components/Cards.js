import React from 'react'
import SCardDesign from './SCardDesign'

const Cards = ({abc}) => {
  return (
    <div className='container'>      
      <div className='row'>
          { abc.map(x=> <SCardDesign name={x} />)}
      </div>
        
    </div>
  )
}

export default Cards

// import React from 'react'

// const Cards = ({name, age}) => {    
//   return (
//     <div>
//        <h1>Component Card</h1>
//        <h1>Name: {name}</h1>
//        <h1>age: {age}</h1>
//        <hr />
        
//     </div>
//   )
// }

// export default Cards

// import React from 'react'

// const Cards = (props) => {
//     const {name, age} = props;
//   return (
//     <div>
//        <h1>Component Card</h1>
//        <h1>Name: {name}</h1>
//        <h1>age: {age}</h1>
//        <hr />
        
//     </div>
//   )
// }

// export default Cards





// import React from 'react'

// const Cards = (props) => {
//   return (
//     <div>
//        <h1>Component Card</h1>
//        <h1>Name: {props.name}</h1>
//        <h1>age: {props.age}</h1>
//        <hr />
        
//     </div>
//   )
// }

// export default Cards


// // const props = {
// //     name: "javed",
// //     age: 21
// // }