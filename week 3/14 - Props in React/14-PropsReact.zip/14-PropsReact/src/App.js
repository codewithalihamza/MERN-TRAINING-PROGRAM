import './App.css';
import Cards from './components/Cards';
import ListDB from './data/PmList';


function App() {

  return (
    <div className="App">
      <Cards abc={ListDB}/> 
    </div>
  );
}

export default App;
