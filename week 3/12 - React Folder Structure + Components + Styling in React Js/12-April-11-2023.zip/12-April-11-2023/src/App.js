import React from 'react'
// import Footer from './components/Footer'
import Header from './components/Header'
import Carousel from './components/Carousel';
import Contact from './components/Contact';
import Services from './components/Services';
// import Home from './components/Home'
// import './header.css'



const App = () =>{
//   const myStyle = {
//     color: 'red',
//     backgroundColor: "yellow",
//     textAlign: "center",
//     textDecoration: "underline"
// }
  

return (

  <div className='MyClass'>


  <Header />
  <Carousel />
  <Contact />
  <br /><br /><br />
  <Services />


    {/* <Header /> */}

      {/* <h1 MyClass='MyClass'>Ramadan Mubarik</h1> */}
      {/* <h2 className='text-primary'>When Eid will be celeberated in Peshawar ?</h2>
      <button className='btn btn-success'>Submit</button> */}

      {/* <h3>Abviously before Muslim</h3>
      <p>Also expected, they even can celebrate twice</p>
      <p>May be with Saudi Arabia and Pakistan as well</p> */}



      {/* <h1 style={myStyle}>Ramadan Mubarik</h1>
      <h2>When Eid will be celeberated in Peshawar ?</h2>
      <h3>Abviously before Muslim</h3>
      <p>Also expected, they even can celebrate twice</p>
      <p>May be with Saudi Arabia and Pakistan as well</p> */}



{/* 
    <h1 style={{color: "blue"}}>Hello Class</h1>
    <h1 style={{color: "green", backgroundColor: "yellow"}}>Hello Class</h1>
    <p style={{color: "red", fontSize: "30px", fontWeight: "bold", textAlign: "center"}}>This is a paragraph</p>
     */}

      {/* <Home />
      <Header />
      <Footer /> */}

  </div>


  // <div>
  //   <h1>Hello World...!!</h1>
  //   <h1>adsjf;lasdjf</h1>
  //   <h1>Hello World...!!</h1>
  //   <h1>adsjf;lasdjf</h1>
  // </div>
)
}

export default App;

