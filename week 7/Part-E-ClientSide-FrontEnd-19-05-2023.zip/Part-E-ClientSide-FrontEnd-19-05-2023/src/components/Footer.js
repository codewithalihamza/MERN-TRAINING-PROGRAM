import React from 'react'

const Footer = () => {
  return (
    <div>
      <h2 className='bg-dark text-light text-center p-3'>All Copyrights reserved &copy; GameTrain</h2>
    </div>
  )
}

export default Footer
