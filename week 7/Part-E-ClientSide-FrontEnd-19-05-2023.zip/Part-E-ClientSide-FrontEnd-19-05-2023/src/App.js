import './App.css';
import {Routes, Route} from 'react-router-dom'
import HomePage from './pages/HomePage'
import Contact from './pages/Contact'
import Login from './pages/Login'
import Register from './pages/Register'
import About from './pages/About'
import Pagenotfound from './pages/Pagenotfound'


function App() {
  return (
    <div className="App">

      <Routes>
            <Route path='/' element={<HomePage />} />
            <Route path='/about' element={<About />} />
            <Route path='/contact' element={<Contact />} />
            <Route path='/login' element={<Login />} />
            <Route path='/register' element={<Register />} />
            <Route path='*' element={<Pagenotfound />} />
      </Routes>  

    </div>
  );
}

export default App;
