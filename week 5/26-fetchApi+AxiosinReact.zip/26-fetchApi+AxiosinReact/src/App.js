import './App.css';
import AxiosApproach from './components/AxiosApproach';
// import AsyncAwait from './components/AsyncAwait';
// import UseEffectReact from './components/UseEffectReact';

function App() {
  return (
    <div className="App">
      {/* <UseEffectReact /> */}
      {/* <AsyncAwait /> */}
      <AxiosApproach />
    </div>
  );
}

export default App;
