import {ADD_TO_CART, REMOVE_TO_CART, EMPTY_CART} from './contant'

const cartReducer = (state=[], action) =>{    
    switch(action.type){
        case ADD_TO_CART:            
            return [action.data, ...state]

        case REMOVE_TO_CART:            
            
            state.length = state.length ? state.length-1 : [];
            return [...state]

        case EMPTY_CART:            
            state = []
            return [...state]

        default:
            return state;
    }
    
}

export default cartReducer;











// if(action.type == "ADD_TO_CART"){
    //     return 1+1
    // }else if(action.type == "REMOVE_FROM_CART"){
    //     return 100
    // }else{
    //     return state
    // }
