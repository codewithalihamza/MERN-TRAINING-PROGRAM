import { ADD_TO_CART, REMOVE_TO_CART, EMPTY_CART } from "./contant"

export const cartData = (data) =>{
    console.log("action called ________> ", data)
    return{
        type: ADD_TO_CART,
        data: data
        
    }

}
export const removeData = (data) =>{
    console.log("removed action called ________> ", data)
    return{
        type: REMOVE_TO_CART,
        data: data        
    }

}
export const cleanData = () =>{    
    return{
        type: EMPTY_CART,        
    }

}