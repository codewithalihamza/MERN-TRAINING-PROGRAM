import { cartData, removeData, cleanData } from '../redux/action';
// import './App.css';
import { useDispatch } from 'react-redux';

function MainPage() {

  const dispatch = useDispatch();

  const product = {
    id: 1,
    name: "samsung",
    price: 200000,
    color: "black"
  }

  return (
    <div className="App">
      <h1>Product Detail Page</h1>        
      <button onClick={()=>dispatch(cartData(product))}>Add to Cart</button>
      <div>
        <button onClick={()=>dispatch(removeData(product.name))}>Remove from Cart</button>
      </div>
      <div>
        <button onClick={()=>dispatch(cleanData())}>Empty Cart</button>
      </div>
    </div>
  );
}

export default MainPage;
