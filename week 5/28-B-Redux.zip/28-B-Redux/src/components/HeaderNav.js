import React from 'react'
import { useSelector } from 'react-redux'


const HeaderNav = () => {

  const productData = useSelector(state=>state.cartAbc)  
  
  return (
    <div className='wrapper'>
        <div className='cartArea'>
            <span>{productData.length}</span>
            <img src='./images/cart.webp' />
        </div>
    </div>
  )
}

export default HeaderNav
