import './App.css';
// import { useDispatch } from 'react-redux';
// import { cartData } from './redux/action';
import HeaderNav from './components/HeaderNav';
import MainPage from './components/MainPage';

function App() {

 
  return (
    <div className="App">      
        <HeaderNav />
        <MainPage />
    </div>
  );
}

export default App;
