import React, {useEffect, useState} from 'react'

const UseEffectReact = () => {    
    const[posts, setPosts] = useState([]);
    
    const postsData = () =>{        
        fetch("https://fakestoreapi.com/products")
        .then(res=>res.json())
        .then(data=>setPosts(data))            
    }


    useEffect(()=>{
        
        postsData();
    })

  return (
    <>
    <h1>UseEffects React Js</h1>

    <div style={{margin: '100px'}}>
        {
            posts.map(singleData=>{
                const {image, title, description} = singleData
                return(
                    <div style={{width: '350px', border: '1px solid red', margin: '10px', float: 'left'}}>
                        
                        <img src={image} width={250} height={300} />
                        <h3>{title.slice(0,11)}</h3>
                        <h3>{description.slice(0,30)}</h3>
                    </div>
                )
            })
        }
    </div>
    </>
  )
}

export default UseEffectReact

