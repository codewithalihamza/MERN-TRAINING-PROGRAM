import React, {useEffect, useState} from 'react'
import Axios from 'axios';


const AxiosAsi = () => {  

    const[posts, setPosts] = useState([]);

    const postsData = () =>{         
        Axios.get("https://fakestoreapi.com/products")
        .then(response=>{setPosts(response.data)})                
    }    

    useEffect(()=>{
           
        postsData();
    },[])

  return (
    <div>
        <h1>Axios in React Js</h1>
      <div style={{margin:'100px'}}>
        {
            posts.map(singlePost=>{
                const {image, title, description} = singlePost
                return(
                    <div style={{width: '350px', border: '3px solid red', margin: '20px auto', borderRadius: '12px', float: 'left'}}>
                        
                        <img src={image} width={250} height={300} />
                        <h3>{title.slice(0,11)}</h3>
                        <h3>{description.slice(0,41)}</h3>
                    </div>
                )
            })
        }
        </div>
    </div>
  )
}

export default AxiosAsi