import './App.css';

import UseEffectAsi from './components/UseEffectAsi';
import AxiosAsi from './components/Axiosasi';
function App() {
  return (
    <div className="App">
     
      {/* <UseEffectAsi/> */}
      <AxiosAsi/>
    </div>
  );
}

export default App;
