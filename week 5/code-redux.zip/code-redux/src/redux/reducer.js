import {ADD_TO_CART} from './contant'

const cartReducer = (state=[], action) =>{    
    switch(action.type){
        case ADD_TO_CART:            
            return [action.data, ...state]
        default:
            return state;
    }
    
}

export default cartReducer;











// if(action.type == "ADD_TO_CART"){
    //     return 1+1
    // }else if(action.type == "REMOVE_FROM_CART"){
    //     return 100
    // }else{
    //     return state
    // }
