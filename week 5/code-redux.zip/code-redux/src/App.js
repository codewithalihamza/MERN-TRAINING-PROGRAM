import './App.css';
import { useDispatch } from 'react-redux';
import { cartData } from './redux/action';

function App() {

  const dispatch = useDispatch();

  const product = {
    id: 1,
    name: "samsung",
    price: 200000,
    color: "black"
  }

  return (
    <div className="App">
      <h1>Redux in ReactJs</h1>

      <button onClick={()=>dispatch(cartData(product))}>Add to Cart</button>

    </div>
  );
}

export default App;
