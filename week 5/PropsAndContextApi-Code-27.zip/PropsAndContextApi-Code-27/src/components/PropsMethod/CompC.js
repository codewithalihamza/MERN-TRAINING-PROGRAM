import React from 'react'

const CompC = ({thirdName}) => {
  return (
    <div>
        <h1>CompC - {thirdName}</h1>
        <p>This is Component C Detail area</p>
    </div>
  )
}

export default CompC
