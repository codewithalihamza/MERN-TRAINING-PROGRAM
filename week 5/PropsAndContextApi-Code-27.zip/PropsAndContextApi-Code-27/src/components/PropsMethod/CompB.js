import React from 'react'
import CompC from './CompC'

const CompB = ({newName}) => {
  return (
    <div>
        {/* <h1>CompB {newName}</h1> */}
        <CompC thirdName={newName} />
    </div>
  )
}

export default CompB
