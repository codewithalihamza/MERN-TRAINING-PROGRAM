import React, { useContext } from 'react'
import CompC from './CompC'
import { FName, LName } from '../../App'

const CompB = () => {
  let fn = useContext(FName)
  let ln = useContext(LName)

  return (
    <div>                
        <h1>Student First Name is : {fn}</h1>
        <h1>Student Last Name is : {ln}</h1>
    </div>
  )
}

export default CompB
