import React from 'react'
import { FName, LName } from '../../App'

const CompC = () => {
  return (
    <div>
        <h1>Comp C Page </h1>
        <hr />

        <FName.Consumer>
            {
              (fname)=>{
                return (
                  <LName.Consumer>
                    {
                      (lname)=>{
                        return <h1>{fname} and {lname}</h1>
                      }
                    }
                  </LName.Consumer>
                )
              }
            }
        </FName.Consumer>
                
    </div>
  )
}

export default CompC
