import React from 'react'
import CompB from './CompB'

const CompA = () => {
  return (
    <div>    
        <CompB />
    </div>
  )
}

export default CompA
