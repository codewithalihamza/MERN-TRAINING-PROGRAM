import { createContext } from 'react';
import './App.css';
// import CompA from './components/PropsMethod/CompA';
import CompA from './components/ContextApi/CompA';

const FName = createContext()
const LName = createContext()

function App() {

  return (

    <div className="App">
      <FName.Provider value={"Altaf"}>
        <LName.Provider value={"Ali"}>
              <CompA />
          </LName.Provider>
      </FName.Provider>

    </div>
  );
}

export default App;
export {FName, LName}
