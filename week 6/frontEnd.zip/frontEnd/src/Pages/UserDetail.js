import React from "react";

const UserDetail = () => {
  return (
    <>
      <div className="container my-5">

      <table className="table table-striped table-hover">
        <thead>
          <tr className="bg-primary text-light">
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Address</th>
            <th scope="col">Email</th>
            <th scope="col">Password</th>
            <th scope="col">&nbsp;</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>Otto</td>
            <td>@mdo</td>
            <td>@mdo</td>
            <td>
                    <a className="btn btn-success btn-sm">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a onClick={()=>alert("user deleted")} className="btn btn-danger btn-sm">
                        <i class="fa-solid fa-trash-can"></i>
                    </a>
            </td>
                
                
                
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>Jacob</td>
            <td>Thornton</td>
            <td>@fat</td>
            <td>@fat</td>
            <td>
                    <a className="btn btn-success btn-sm">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a className="btn btn-danger btn-sm">
                        <i class="fa-solid fa-trash-can"></i>
                    </a>
            </td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td >Larry the Bird</td>
            <td >abc</td>
            <td>@twitter</td>
            <td>@twitter</td>
            <td>
                    <a className="btn btn-success btn-sm">
                        <i class="fas fa-edit"></i>
                    </a>
                    <a className="btn btn-danger btn-sm">
                        <i class="fa-solid fa-trash-can"></i>
                    </a>
            </td>
          </tr>
        </tbody>
      </table>
      </div>
    </>
  );
};

export default UserDetail;
