const express = require('express');
const dbConnection = require('./db/config');
const User = require("./db/User")
const app = express();
app.use(express.json());
dbConnection();



app.post("/register",async(req, resp)=>{
    let user = new User(req.body)
    let result = await user.save();
    resp.send(result)
    
    // if(result){
    //     resp.send(result)
    //     console.log({msg:"Data saved successfully"})
    // }else{
    //     console.log({msg:"Something went wrong"})
    // }
})



port = 5000

app.listen(port,()=>{
    console.log(`Server started at PORT ${port}`)
})