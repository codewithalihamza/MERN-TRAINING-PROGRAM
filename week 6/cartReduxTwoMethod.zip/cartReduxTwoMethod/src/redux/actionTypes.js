export const CLEAR_ITEMS = "CLEAR_ITEMS";
export const REMOVE = "REMOVE";
export const INCREASE = "INCREASE";
export const DECREASE = "DECREASE";
export const GET_TOTALS = "GET_TOTALS";
export const DISPLAY_ITEMS = "DISPLAY_ITEMS";
