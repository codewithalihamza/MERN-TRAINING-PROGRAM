const express = require('express');
const dbConnection = require('./db/config');
const dotenv = require('dotenv')
const cors = require('cors')
const User = require("./db/User")
const app = express();
app.use(express.json());
dbConnection();
dotenv.config();
app.use(cors());


// posting data in MongoDb
app.post("/register",async(req, resp)=>{
    let user = new User(req.body)    
    let result = await user.save();
    resp.send(result)
})

// getting Data from MongoDb

app.get("/users",async(req, res)=>{
    let uData = await User.find();        
    if(uData.length>0){
        res.send(uData)
    }else{
        res.send({msg: "No record available"})
    }
})

// deleting user by id
app.delete("/users/:id",async(req,res)=>{    

    let delUser = await User.deleteOne({_id: req.params.id})
    res.send(delUser)

})






const PORT = process.env.port || 8000

app.listen(PORT,()=>{
    console.log(`Server started at PORT ${PORT} in ${process.env.App_Mod}`)
})