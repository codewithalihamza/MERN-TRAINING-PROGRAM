const express = require('express');
const app = express();

app.get('/',(req,res)=>{
    console.log("Welcome to BackEnd")
});
app.get('/user',(req,res)=>{    
    res.send("Users Data called")
});

app.post('/user',(req,res)=>{
    res.send("<h1>Data on Front End</h1>")
});


port = 5000;
app.listen(port,()=>{
    console.log(`Server is started at Port ${port}`)
})
















// app.post();

// app.put();

// app.delete()


