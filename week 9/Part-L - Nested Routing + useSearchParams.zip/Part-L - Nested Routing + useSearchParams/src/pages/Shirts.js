import React from 'react'

const Shirts = () => {
  return (
    <div>
      <h2>All Shirts Data Available</h2>
    </div>
  )
}

export default Shirts
