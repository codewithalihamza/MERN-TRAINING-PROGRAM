import React from 'react'

const Jeans = () => {
  return (
    <div>
      <h2>All Jeans Data Available</h2>
    </div>
  )
}

export default Jeans
