import React from 'react'

const Shoes = () => {
  return (
    <div>
            <h2>All Shoes Data Available</h2>

    </div>
  )
}

export default Shoes
