const ListDB = [
    {
        id: 1,
        pName: "Shirt One",
        pic: "./photos/pic.jpg",
        price: 2500,
    },
    {
        id: 2,
        pName: "Shirt Two",
        pic: "./photos/pic2.jpg",
        price: 2300,
    },
    {
        id: 3,
        pName: "Shirt Three",
        pic: "./photos/pic5.jpg",
        price: 3200,
    },
    {
        id: 4,
        pName: "Shirt Four",
        pic: "./photos/pic6.webp",
        price: 3500,
    },
]
export default ListDB;


