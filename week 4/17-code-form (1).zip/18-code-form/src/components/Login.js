import React, { useState } from 'react'
const Login = () => {
    const[name, setName] = useState('')
    const[address, setAddress] = useState('')

    const nameChange = (event) =>{
        setName(event.target.value)
    }
    const addressChange = (event) =>{
        setAddress(event.target.value)
    }

    const[newEntry, SetNewEntry] = useState([])


    const saveData = () =>{      
      
      if(name && address){
        let oldData = {name:name, address:address}      
        SetNewEntry([...newEntry, oldData])
        setName('')
        setAddress('')
      }else{
        alert("please enter required field")
      }
      
    }


  return (
    <div>
        
        Name: <input type='text' name='name' value={name} onChange={nameChange} required />
        <br /><br />        
        Address: <input type='text' name='address' value={address} onChange={addressChange} required />
        <br /><br />    

        <button onClick={saveData}>Save Data</button>    
        <hr />

    <table width={350} align='center' cellPadding={10} border={1}>
        <tr>
          <td>Sr. No.</td>
          <td>Name</td>
          <td>Address</td>
        </tr>

            {
              newEntry.map((x, i)=>{
                return(
                  <>
                    <tr>
                        <td>{i+1}</td>
                        <td>{x.name}</td>
                        <td>{x.address}</td>
                    </tr>
                  </>
                )
              })
            } 
       </table>

    </div>
  )
}

export default Login
