import React, { useState } from 'react'

const Increment = () => {

    const[countx, SetCountX] = useState(0)
    const[county, SetCountY] = useState(0)


  return (
    <div>
      <h1>Value of X : {countx}</h1>      
      <h1>Value of Y : {county}</h1>
    
        <button onClick={()=>SetCountX(countx+1)}>Inc X</button>
        <button onClick={()=>SetCountY(county+1)}>Inc Y</button>

    </div>
  )
}

export default Increment
