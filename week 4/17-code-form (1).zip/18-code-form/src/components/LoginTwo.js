import React, { useState } from "react";

const LoginTwo = () => {
  

  const [userInfo, setUserInfo] = useState({
    name: "",
    email: "",
    address: "",
    age: ''
  });

  

  const inputHandler = (event) => {
    
    // const { value } = event.target
    // console.log("value : ", value)
    
    // const { name } = event.target
    // console.log(name)
    // console.log("name : ", name)

    setUserInfo({...userInfo, [event.target.name]: event.target.value})


    // setUserInfo({...userInfo, [event.target.name]: event.target.value})
    // setUserInfo(
    //   {...userInfo, [event.target.name]: event.target.value}
    // )
    // console.log(userInfo)

  };

  const[newRecord, setNewRecord] = useState([])


  const saveRecord = () =>{
    let copyData = {...userInfo}
    setNewRecord([...newRecord, copyData])    
    setUserInfo({name: '', email: '', address: '', age: ''})
    console.log(userInfo)

  }



  return (
    <div>
      <h1>Form Two in React JS</h1>
      Name:
      <input
        type="text"
        value={userInfo.name}
        name="name"
        onChange={inputHandler}
      />
      <br />
      Email:
      <input
        type="text"
        value={userInfo.email}
        name="email"
        onChange={inputHandler}
      />
      <br />      
      Address:
      <input
        type="text"
        value={userInfo.address}
        name="address"
        onChange={inputHandler}
      />
      <br />
      Age:<input
        type="text"
        value={userInfo.age}
        name="age"
        onChange={inputHandler}
      />
      <br />
      <br />
      <button onClick={saveRecord}>Save Data</button>
    </div>
  );
};

export default LoginTwo;
