import './App.css';
import LoginTwo from './components/LoginTwo';
// import Increment from './components/Increment';
// import Login from './components/Login';

function App() {
  return (
    <div className="App">
        {/* <Increment /> */}
        <LoginTwo />

        {/* <Login /> */}

    </div>
  );
}

export default App;
